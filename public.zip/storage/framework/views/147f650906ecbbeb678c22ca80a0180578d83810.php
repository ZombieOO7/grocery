<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="contact_us_checkbox[]" value="<?php echo e(@$contact->id); ?>" class="m-checkable contact_us_checkbox checkbox checkAll" data-email="<?php echo e(@$contact->email); ?>">
    <span></span>
</label>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/contact-us/_add_checkbox.blade.php ENDPATH**/ ?>