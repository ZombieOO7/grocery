    <a class=" view" href="<?php echo e(URL::signedRoute('banner.edit',['uuid'=>@$banner->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" href="javascript:;" id="<?php echo e(@$banner->uuid); ?>" data-table_name="banner_table" data-url="<?php echo e(route('banner.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$banner->status=='1'): ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$banner->uuid); ?>" data-url="<?php echo e(route('banner.active_inactive', [@$banner->id])); ?>" data-table_name="banner_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$banner->uuid); ?>" data-url="<?php echo e(route('banner.active_inactive', [@$banner->id])); ?>" data-table_name="banner_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/banner/_add_action.blade.php ENDPATH**/ ?>