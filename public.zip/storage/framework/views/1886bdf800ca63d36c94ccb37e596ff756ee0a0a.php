    <a class=" view" href="<?php echo e(URL::signedRoute('chat-group.edit',['uuid'=>@$chatGroup->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" href="javascript:;" id="<?php echo e(@$chatGroup->uuid); ?>" data-table_name="chat_group_table" data-url="<?php echo e(route('chat-group.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$chatGroup->status=='1'): ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$chatGroup->uuid); ?>" data-url="<?php echo e(route('chat-group.active_inactive', [@$chatGroup->id])); ?>" data-table_name="chat_group_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$chatGroup->uuid); ?>" data-url="<?php echo e(route('chat-group.active_inactive', [@$chatGroup->id])); ?>" data-table_name="chat_group_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/chat-group/_add_action.blade.php ENDPATH**/ ?>