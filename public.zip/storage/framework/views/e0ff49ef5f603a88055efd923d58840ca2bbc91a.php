<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="trade_checkbox[]" value="<?php echo e($emailTemplate->id); ?>" class="m-checkable trade_checkbox checkbox">
    <span></span>
</label><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/email-template/_add_checkbox.blade.php ENDPATH**/ ?>