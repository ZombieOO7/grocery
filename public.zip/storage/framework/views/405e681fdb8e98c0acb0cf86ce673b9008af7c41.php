<?php $__env->startSection('content'); ?>
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->startSection('title', trans('formname.contact_us_list')); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <!-- END: Subheader -->
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-portlet m-portlet--mobile">

            <div class="m-portlet__body">
                <div class="m-form__content">
                    <h5><?php echo e(trans('formname.contact_us_list')); ?></h5>
                </div>
                <hr>
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <select class="form-control" name="action" id='action' aria-invalid="false">
                                <option value=""><?php echo e(trans('formname.action')); ?></option>
                                <?php if((\Auth::guard('admin')->user()->can('contact us multiple delete'))): ?>
                                <option value="delete"><?php echo e(trans('formname.delete')); ?></option>
                                <?php endif; ?>
                            </select>
                            <a href="javascript:;" class="btn btn-primary submit_btn" id='action_submit'
                                data-url="<?php echo e(route('contact_us_multi_delete')); ?>"
                                data-table_name="contact_us_table"><?php echo e(trans('formname.submit')); ?></a>
                            <button class="btn btn-info" style='margin:0px 0px 0px 12px' id='clr_filter'
                                data-table_name="contact_us_table"><?php echo e(trans('formname.clear_filter')); ?></button>
                        </div>
                        

                    </div>

                    
                </div>
                
                <!--begin: Datatable -->
                <table class="table table-striped- table-bordered table-hover table-checkable" id="contact_us_table">
                    <thead>
                        <tr>
                            <th class="nosort">
                                <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
                                    <input type="checkbox" value="" id="contact_us_checkbox"
                                        class="m-checkable allCheckbox" onclick="CheckUncheckAll(this)">
                                    <span></span>
                                </label>
                            </th>
                            
                            <th><?php echo e(trans('formname.full_name')); ?></th>
                            <th><?php echo e(trans('formname.email')); ?></th>
                            <th><?php echo e(trans('formname.subject')); ?></th>
                            <th><?php echo e(trans('formname.message')); ?></th>
                            <th><?php echo e(trans('formname.message_date')); ?></th>
                            <th><?php echo e(trans('formname.action')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <td></td>
                            
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.full_name')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.email')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.subject')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.message')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.message_date')); ?>"></th>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
<!-- Show Description Modal -->
<div class="modal fade def_mod dtails_mdl" id="DescModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content ">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            <div class="modal-body">
                <h3 class="mdl_ttl"><?php echo e(__('formname.message')); ?></h3>
                <p class="mrgn_tp_20 show_desc" style="word-wrap: break-word;">

                </p>
                <button type="button" class="btn btn-success pull-right" data-dismiss="modal"><?php echo e(__('formname.close')); ?></button>
            </div>
        </div>
    </div>
</div>

<!-- Show Description Modal -->
<div class="modal fade def_mod dtails_mdl" id="SubjModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content ">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            <div class="modal-body">
                <h3 class="mdl_ttl"><?php echo e(__('formname.subject')); ?></h3>
                <p class="mrgn_tp_20 show_sbjct" style="word-wrap: break-word;">

                </p>
                <button type="button" class="btn btn-success pull-right" data-dismiss="modal"><?php echo e(__('formname.close')); ?></button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php /*Load script to footer section*/?>

<?php $__env->startSection('inc_script'); ?>
<script>
    var contact_us_list_url = "<?php echo e(route('contact_us_datatable')); ?>";
/** Show description modal */
$(document).on('click','.shw-dsc',function(e) {
    $(document).find('.show_desc').html($(this).attr('data-description'));
    $(document).find('.show_sbjct').html($(this).attr('data-subject'));
});
</script>
<script src="<?php echo e(asset('backend/js/contact-us/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/contact-us/index.blade.php ENDPATH**/ ?>