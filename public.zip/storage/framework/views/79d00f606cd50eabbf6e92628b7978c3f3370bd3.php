<span class="" style="color:<?php echo e(@config('constant.job_status_color')[$job->job_status_id]); ?>">
    <?php echo e(@$job->jobStatus->title); ?>

</span>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/job/_add_color_code.blade.php ENDPATH**/ ?>