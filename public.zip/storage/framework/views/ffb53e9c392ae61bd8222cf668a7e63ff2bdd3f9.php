
<?php echo e(Str::limit(@$location->title, 30)); ?>

<?php if(strlen(@$location->title) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc"  data-description="<?php echo e(@$location->title); ?>" data-toggle="modal" data-target="#DescModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/location/_add_message.blade.php ENDPATH**/ ?>