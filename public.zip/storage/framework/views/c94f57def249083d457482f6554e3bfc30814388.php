<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="user_checkbox[]" value="<?php echo e($user->id); ?>" class="m-checkable user_checkbox checkbox">
    <span></span>
</label><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/user/_add_checkbox.blade.php ENDPATH**/ ?>