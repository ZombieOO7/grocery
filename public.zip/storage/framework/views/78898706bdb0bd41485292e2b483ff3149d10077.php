<?php $__env->startSection('content'); ?>
<?php
$title = 'Job Report';
?>
<?php $__env->startSection('title', @$title); ?>
<?php
$months = monthList();
$date = dateList();
?>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
	<div class="m-content">
		<div class="row">
			<div class="col-lg-12">
				<div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
					id="main_portlet">
					<div class="m-portlet__head">
						<div class="m-portlet__head-wrapper">
							<div class="m-portlet__head-caption">
								<div class="m-portlet__head-title">
									<h3 class="m-portlet__head-text">
										<?php echo e(@$title); ?>

									</h3>
								</div>
							</div>
						</div>
					</div>
					<div class="m-portlet__body">
						<div class="m-form__section m-form__section--first">
							<?php echo e(Form::open(['route' => 'report.generate','method'=>'POST','class'=>'m-form m-form--fit m-form--label-align-right','id'=>'m_form_1'])); ?>

							<div class="m-portlet__body">
								<div class="m-form__content">
									<?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
									<?php if($errors->any()): ?>
										<div class="alert alert-danger">
											<ul>
												<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><?php echo e($error); ?></li>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</ul>
										</div>
									<?php endif; ?>
									<div class="m-alert m-alert--icon alert alert-danger m--hide" role="alert"
										id="m_form_1_msg">
										<div class="m-alert__icon">
											<i class="la la-warning"></i>
										</div>
										<div class="m-alert__text">
											<?php echo e(__('admin/messages.required_alert')); ?>.
										</div>
										<div class="m-alert__close">
											<button type="button" class="close" data-close="alert" aria-label="Close">
											</button>
										</div>
									</div>
									<div class="m-alert m-alert--icon alert alert-danger m--hide" role="alert"
										id="m_form_2_msg">
										<div class="m-alert__icon">
											<i class="la la-warning"></i>
										</div>
										<div class="m-alert__text">
											<?php echo e(__('admin/messages.not_found')); ?>.
										</div>
										<div class="m-alert__close">
											<button type="button" class="close" data-close="alert" aria-label="Close">
											</button>
										</div>
									</div>
								</div>
								<div class="m-form__actions">
									<div class="row">
										<div class="col-lg-10 ml-lg-auto">
											<?php echo Form::button('Annually', ['id'=>'yearly','class' => 'btn btn-primary'] ); ?>

											<?php echo Form::button('Monthly', ['id'=>'monthly','class' => 'btn btn-primary'] ); ?>

											<?php echo Form::button('Daily', ['id'=>'daily','class' => 'btn btn-primary'] ); ?>

											<?php echo Form::hidden('reportCategory',null,['id'=>'reportCategory']); ?>

										</div>
									</div>
								</div>
								<div class="form-group m-form__group row" id='yearInput' style="display:none;">
									<?php echo Form::label(__('formname.report.year').'*', null,['class'=>'col-form-label col-lg-2 col-sm-12']); ?>

									<div class="col-lg-6 col-md-9 col-sm-12">
										<?php echo Form::text('year',@$report->year,['class'=>'form-control
										m-input','id'=>'year','readonly'=>true]); ?>

										<?php if($errors->has('year')): ?> <p style="color:red;">
											<?php echo e($errors->first('year')); ?></p> <?php endif; ?>
									</div>
								</div>
								<div class="form-group m-form__group row" id='monthInput' style="display:none;">
									<?php echo Form::label(__('formname.report.month'),
									null,array('class'=>'col-form-label col-lg-2 col-sm-12')); ?>

									<div class="col-lg-6 col-md-9 col-sm-12">
										<div class="input-group">
											<?php echo Form::select('month',@$months,[],['class'=>'form-control
											m-bootstrap-select ','id'=>'month','multiple'=>false, 'style'=>'width:100%;','data-none-selected-text' => __('formname.report.select_month') ]); ?>

										</div>
										<span class="monthsError">
											<?php if($errors->has('months')): ?>
											<p class="errors"><?php echo e($errors->first('month')); ?></p>
											<?php endif; ?>
										</span>
										<span class="m-form__help"></span>
									</div>
								</div>
								<div class="form-group m-form__group row" id='dayInput' style="display:none;">
									<?php echo Form::label(__('formname.report.date'),
									null,array('class'=>'col-form-label
									col-lg-2 col-sm-12')); ?>

									<div class="col-lg-6 col-md-9 col-sm-12">
										<div class="input-group">
											<?php echo Form::select('date',@$date,[],['class'=>'form-control
											m-bootstrap-select ','id'=>'date','style'=>'width:100%;','multiple'=>false ,'data-none-selected-text' => __('formname.report.select_date') ]); ?>

										</div>
										<span class="daysError">
											<?php if($errors->has('days')): ?>
											<p class="errors"><?php echo e($errors->first('days')); ?></p>
											<?php endif; ?>
										</span>
										<span class="m-form__help"></span>
									</div>
								</div>
								<div class="form-group m-form__group row">
									<?php echo Form::label(__('formname.report.report_type').'*',
									null,array('class'=>'col-form-label
									col-lg-2 col-sm-12')); ?>

									<div class="col-lg-6 col-md-9 col-sm-12">
										<div class="input-group">
											<?php echo Form::select('report_type',@$reportType,[],['class'=>'form-control ','id'=>'reportType','multiple'=>false 
											,'data-none-selected-text' => __('formname.select_type',['type'=>'job Status']) ]); ?>

										</div>
										<span class="reportTypeError">
											<?php if($errors->has('report_type')): ?>
											<p class="errors"><?php echo e($errors->first('report_type')); ?></p>
											<?php endif; ?>
										</span>
										<span class="m-form__help"></span>
									</div>
								</div>
								<div id="dynamicFilters">

								</div>
								
								<div class="form-group m-form__group row">
									<?php echo Form::label(__('formname.report.export_to').'*',
									null,array('class'=>'col-form-label
									col-lg-2 col-sm-12')); ?>

									<div class="col-lg-6 col-md-9 col-sm-12">
										<div class="input-group">
											<?php echo Form::select('export_to',@[''=>'Select','.csv'=>'CSV','.xls'=>'Excel'],[],['class'=>'form-control','id'=>'export_to'
											,'data-none-selected-text' => __('formname.report.export_to') ]); ?>

										</div>
										<span class="exportError">
											<?php if($errors->has('export_to')): ?>
											<p class="errors"><?php echo e($errors->first('export_to')); ?></p>
											<?php endif; ?>
										</span>
										<span class="m-form__help"></span>
									</div>
								</div>
								<?php echo Form::hidden('id',@$report->id ,['id'=>'id']); ?>

								<div class="m-portlet__foot m-portlet__foot--fit">
									<div class="m-form__actions m-form__actions">
										<div class="row">
											<div class="col-lg-10 ml-lg-auto">
												<?php echo Form::button(__('formname.view'), ['id'=>'viewReport','class' => 'btn btn-success'] ); ?>

												<?php echo Form::submit(__('formname.export'), ['class' => 'btn btn-primary'] ); ?>

												<?php echo Form::button(__('formname.clear_filter'), ['id'=>'clearBtn','class' => 'btn btn-info'] ); ?>

											</div>
										</div>
									</div>
								</div>
							</div>
							<?php echo Form::close(); ?>

							<div class="m-portlet__body" id="tableContent">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
	var url = "<?php echo e(route('report.view')); ?>";
	var getReportType = "<?php echo e(route('report.type.data')); ?>";
	var getMachineList = "<?php echo e(route('getmachine')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/report/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/reports/index.blade.php ENDPATH**/ ?>