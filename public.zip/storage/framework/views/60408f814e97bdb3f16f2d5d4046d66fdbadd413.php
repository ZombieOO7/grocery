<?php if((\Auth::guard('admin')->user()->can('contact us edit'))): ?>

<?php endif; ?>

<a class=" delete" href="javascript:;" id="<?php echo e(@$contact->id); ?>"  data-table_name="contact_us_table"
    data-url="<?php echo e(route('contact_us_delete')); ?>" title="Delete Contact Us"><i class="fas fa-trash-alt"></i>
</a>
<a class="detail" href="<?php echo e(route('contact_us_detail',['uuid'=>@$contact->uuid])); ?>" id="<?php echo e(@$contact->id); ?>" data-table_name="contact_us_table" title="Detail"><i class="fas fa-eye"></i>
</a>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/contact-us/_add_action.blade.php ENDPATH**/ ?>