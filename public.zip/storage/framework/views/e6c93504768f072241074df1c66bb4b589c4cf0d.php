
<?php 
// require_once 'vendor/autoload.php';
// use Google\Cloud\Firestore\FirestoreClient;

// $db = new FirestoreClient([
//     'projectId'=>'project-hub-67711'
// ]);
// echo '<pre>';print_r($db);exit;

$userID = 1;//base64_decode($_GET['userID']); 
$access_token = "eyJ1c2VybmFtZSI6InJlaXNhbmcucmlzb21AY2F1c2V3YXkuY29tIiwiZXhwaXJ5IjowLCJvcmlnaW4iOiIxMC4yMC4xMC4yMyIsImlzRGV2aWNlIjpmYWxzZX0";
//?ebdm=true
$ch = curl_init("https://etender.staging.causeway.com/tenderservices/api/estimator/project/composite/list");
$data_string = '{"pageSize":20,"totalRecord":106,"currentPage":1,"filters":[ {
    "dataType": "STRING",
    "name": "name",
    "operand": "LIKE",
    "value": ""
  }]}';


//curl_setopt($ch, CURLOPT_FILE, $fp);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json","Authorization: Bearer ".$access_token));
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);


$response = json_decode(curl_exec($ch));
$contractors_arr = [];
// dd($response->content);
// foreach($response->content as $projects){
//     foreach($projects->tenders as $subProjects){
//         foreach($subProjects->users as $contractors){
//             $contractors_arr[$contractors->id] = $contractors->name;
//         }
//     }
// }
//echo '<pre>';print_r($contractors_arr);exit;

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('backend/chat/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/chat/css/bootstrap-select.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/select2.min.css')); ?>"  rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?>"  rel="stylesheet">
    <link href="<?php echo e(asset('backend/chat/css/style.css')); ?>" rel="stylesheet">
    <title>Chat</title>
    <style>
        .hid_spn{
            display: none !important;
        }
        .red { 
            color: #000000
        }
        .selected { 
            background-color : #38D878 !important
        }
        .error {
            color:red;
            font-size: 14px;
        }
        /* .msg_list li.rt_cnvstn h4 { */
            /* background-color: #38D878; */
        /* } */
    </style>
</head>
<body>
<div class="main">
<div id='ajax_loader' style='display:none;'><p>Loading...</div>

        <input type="hidden" id="userID" value="<?php echo $userID; ?>">
        <input type="hidden" id="responderList" value="">
        <input type="hidden" id="contractorsList" value='<?php echo !empty($contractors_arr) ? json_encode($contractors_arr) : ''; ?>'>
        <input type="hidden" id="limit" value='10'>

        <div class="container-fluid">
            <div class="title_main">
                <div class="pdng_cls">
                    <h1>Messages</h1>
                    <form id="search_scn">
                    <div class="main_search_scn">
                        <div class="top-serch-filter-bar" style="display: none;">
                            <div class="form-group mrgn-btm-5 eqaul-wdth">
                                <div class="df-select scnd-slct">
                                    <select class="selectpicker1" name="userId" id="userId" title="Select Members">
                                        <option value="">Select Member</option>
                                    </select>
                                    <span class="userError"></span>
                                </div>
                            </div>
                            <div class="form-group mrgn-btm-5 eqaul-wdth">
                                <div class="df-select scnd-slct">
                                    <input type="textbox" class="datepicker1" name="startDate" id="startDate" placeholder="Start Date">
                                </div>
                            </div>
                            <div class="form-group mrgn-btm-5 eqaul-wdth">
                                <div class="df-select scnd-slct">
                                    <input type="textbox" class="datepicker1" name="endDate" id="endDate" placeholder="End Date">
                                </div>
                            </div>
                            <div class="form-group mrgn-btm-5">
                                <div class="png-right-15">
                                    <input type="button" class="btn btn-primary serch_btn" name="searchFilter" id="searchFilter" value="Search">
                                </div>
                            </div>
                            <div class="form-group mrgn-btm-5">
                                <div class="png-right-15">
                                    <input type="button" class="btn btn-primary reset_btn" name="resetFilter" id="resetFilter" value="Reset">
                                </div>
                            </div>
                        </div>
                        <a class="filter_btn" href="#"><i class="fa fa-filter" aria-hidden="true"></i></a>
                    </div>
                    </form>
                </div>
            </div>
        </div>
       <div class="sidebar">
           <button class="open_btn">
               <i class="fa fa-chevron-right" aria-hidden="true"></i>
               <i class="fa fa-chevron-left" aria-hidden="true"></i>
           </button>
           <div class="inner_serch_scn">
               <div class="container-fluid">
                   <div class="form-group serch_input mrgn-btm-5">
                       <input type="text" class="form-control ctmn_frm_cntl" id="search_messages" placeholder="Search Messages">
                       <i class="fa fa-search" aria-hidden="true"></i>
                   </div>
                   <div class="form-group">
                       <div id="fltr" class="df-select scnd-slct" style="display:none">
                            <button id="prev" class="btn btn-outline-primary"><span class="fa fa-angle-left"></span></button>
                            <button id="next" class="btn btn-outline-primary"><span class="fa fa-angle-right"></span></button>
                            <button id="clr" class="btn btn-outline-danger"><span class="fa fa-trash"></span></button>
                       </div>
                   </div>
               </div>
               <div class="inner_msg_list">
               </div>
           </div>
       </div>
       
       <div class="middle-body">
           <div class="msg_box">
           </div>
           <div class="chat_box">
               <form class="position-relative">
                   <input type="text" class="form-control" autocomplete="off" id="messageText" placeholder="Write a message...">
                   <button type="submit" class="chat_btn" id="sendMessage"><i></i></button>
               </form>
           </div>
       </div>
</div>
<?php
use Illuminate\Support\Facades\Auth;
$adminId = Auth::id();
?>

<script src="<?php echo e(asset('backend/chat/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/chat/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/chat/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/chat/js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-datepicker.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/firebase.js')); ?>"></script>
<script src="<?php echo e(asset('js/firebase-app.js')); ?>"></script>
<script src="<?php echo e(asset('js/firebase-firestore.js')); ?>"></script>
<script>
    var token ="<?php echo e(csrf_token()); ?>";
    var groupMembers = '<?php echo e(route("chat.group-members")); ?>';
    var getMessageUrl = '<?php echo e(route("chat.group-messages")); ?>';
    var sendMessageUrl = '<?php echo e(route("chat.send-message")); ?>';
    var adminId = '<?php echo e($adminId); ?>';
    var getSideMenu = "<?php echo e(route('chat.sideMenu')); ?>";
    var searchMessageUrl = "<?php echo e(route('chat.search-message')); ?>";
    var time = Number('<?php echo e(firebasetime()); ?>');
    var adminName= '<?php echo e(Auth::user()->full_name_text); ?>';
    
</script>
<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/chat/js/index.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/chat/index.blade.php ENDPATH**/ ?>