<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', @$title); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<style>
    .commonSelect {
        width: 100% !important;
        overflow: hidden !important;
        white-space: pre !important;
        text-overflow: ellipsis !important;
    }
    .ui-autocomplete {
    max-height: 100px;
    overflow-y: auto;
    /* prevent horizontal scrollbar */
    overflow-x: hidden;
  }
  /* IE 6 doesn't support max-height
   * we use height instead, but this forces the menu to always be this tall
   */
  * html .ui-autocomplete {
    height: 100px;
  }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e(@$title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <a href="<?php echo e(route('machine.index')); ?>"
                                    class="btn btn-secondary m-btn m-btn--air m-btn--custom">
                                    <span>
                                        <i class="la la-arrow-left"></i>
                                        <span><?php echo e(__('formname.back')); ?></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <?php if(isset($machine) || !empty($machine)): ?>
                        <?php echo e(Form::model($machine, ['route' => ['machine.store', @$machine->uuid], 'method' => 'PUT','id'=>'m_form_1','class'=>'m-form m-form--fit m-form--label-align-right','files' => true,'autocomplete' => "off"])); ?>

                        <?php else: ?>
                        <?php echo e(Form::open(['route' => 'machine.store','method'=>'post','class'=>'m-form m-form--fit m-form--label-align-right','id'=>'m_form_1','files' => true,'autocomplete' => "off"])); ?>

                        <?php endif; ?>
                            <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.machine.location').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('location_id', @$locationList, @$machine->location_id,
                                    ['class' =>'form-control commonSelect', 'id'=>'locationId' ]); ?>

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.machine.title').'*', null,['class'=>'col-form-label
                                col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('title',@$machine->title,['id'=>'names','class'=>'form-control
                                    m-input err_msg','maxlength'=>config('constant.name_length'),'placeholder'=>__('formname.machine.title')]); ?>

                                    <?php if($errors->has('title')): ?>
                                        <p style="color:red;"><?php echo e($errors->first('title')); ?></p> 
                                    <?php endif; ?>
                                </div>
                            </div>

                            
                            <?php echo Form::hidden('id',@$machine->id ,['id'=>'id']); ?>

                            <div class="m-portlet__foot m-portlet__foot--fit">
                                <div class="m-form__actions m-form__actions">
                                    <br>
                                    <div class="row">
                                        <div class="col-lg-9 ml-lg-auto">
                                            <?php echo Form::submit(__('formname.submit'), ['class' => 'btn btn-success'] ); ?>

                                            <a href="<?php echo e(Route('machine.index')); ?>"
                                                class="btn btn-secondary"><?php echo e(__('formname.cancel')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php echo Form::close(); ?>

                    </div>
                    <div id="machineList" style="display: none;" class="m-portlet__body">
                        <div class="m-form__content">
                            <h5><?php echo e(__('formname.machine.list')); ?></h5>
                        </div>
                        <hr>
                        <!--begin: Datatable -->
                        <table class="table table-striped- table-bordered table-hover table-checkable for_wdth" id="machine_table"
                            data-type="" data-url="<?php echo e(route('machine.datatable')); ?>">
                            <thead>
                                <tr>
                                    <th><?php echo e(__('formname.machine.title')); ?></th>
                                    <th><?php echo e(__('formname.machine.location')); ?></th>
                                    <th><?php echo e(__('formname.created_at')); ?></th>
                                    <th><?php echo e(__('formname.status')); ?></th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                        placeholder="<?php echo e(__('formname.machine.title')); ?>"></th>
                                    <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                        placeholder="<?php echo e(__('formname.machine.location')); ?>"></th>
                                    <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                        placeholder="<?php echo e(__('formname.created_at')); ?>"></th>
                                    <th class="slct-wdth">
                                        <select class="statusFilter form-control form-control-sm tbl-filter-column">
                                            <?php $__empty_1 = true; $__currentLoopData = $statusList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <?php endif; ?>
                                        </select>
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
    $(document).find('.selectpicker').selectpicker({  
        placeholder: "Select Paper Category",
        allowClear: true
    }) 
    // $(document).find("#paper_category").select2();
</script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script>
var rule = $.extend({}, <?php echo json_encode(config('constant'), JSON_FORCE_OBJECT); ?>);
var formname = $.extend({}, <?php echo json_encode(__('formname'), JSON_FORCE_OBJECT); ?>);
var id = '<?php echo e(@$user->id); ?>';
var url = "<?php echo e(route('machine.datatable')); ?>";
var getMachineName = "<?php echo e(route('machine.list')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/machine/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/machine/create.blade.php ENDPATH**/ ?>