
<?php echo e(Str::limit(@$machine->title, 30)); ?>

<?php if(strlen(@$machine->title) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc" data-title="<?php echo e($title); ?>"  data-description="<?php echo e(@$machine->title); ?>" data-toggle="modal" data-target="#DescModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/machine/_add_message.blade.php ENDPATH**/ ?>