<ul class="msg_list">
    <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php if(isset($message['admin_id'])): ?>
        <li class="rt_cnvstn">
        <div class="name_time">
            <p><?php echo e(@$message['name']); ?></p>
            <p><?php echo e(@$message['created_at']); ?></p>
        </div>
        <h4 class='serchMsg'><?php echo e(@$message['message']); ?></h4>
        </li>
        <div class="clearfix"></div>
    <?php else: ?>
        <li class="lf_cnvstn">
        <div class="name_time">
            <p><?php echo e(@$message['name']); ?></p>
            <p><?php echo e(@$message['created_at']); ?></p>
        </div>
        <h4 class='serchMsg'><?php echo e(@$message['message']); ?></h4>
        </li>
        <div class="clearfix"></div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
    <?php endif; ?>
</ul>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/chat/message.blade.php ENDPATH**/ ?>