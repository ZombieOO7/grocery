    <a class=" view" data-job_url="<?php echo e(route('machine.jobstatus')); ?>" href="<?php echo e(URL::signedRoute('machine.edit',['uuid'=>@$machine->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" data-job_url="<?php echo e(route('machine.jobstatus')); ?>" href="javascript:;" id="<?php echo e(@$machine->uuid); ?>" data-table_name="machine_table" data-url="<?php echo e(route('machine.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$machine->status=='1'): ?>
        <a class=" active_inactive" data-job_url="<?php echo e(route('machine.jobstatus')); ?>" href="javascript:;" id="<?php echo e(@$machine->uuid); ?>" data-url="<?php echo e(route('machine.active_inactive', [@$machine->id])); ?>" data-table_name="machine_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" data-job_url="<?php echo e(route('machine.jobstatus')); ?>" href="javascript:;" id="<?php echo e(@$machine->uuid); ?>" data-url="<?php echo e(route('machine.active_inactive', [@$machine->id])); ?>" data-table_name="machine_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/machine/_add_action.blade.php ENDPATH**/ ?>