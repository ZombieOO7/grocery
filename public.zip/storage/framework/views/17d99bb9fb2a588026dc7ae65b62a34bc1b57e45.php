<?php if(@$product->status == 0): ?>
    <span class="m-badge  m-badge--danger m-badge--wide"><?php echo e(__('Inactive')); ?></span>
<?php else: ?>
    <span class="m-badge  m-badge--success m-badge--wide"><?php echo e(__('Active')); ?></span>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/product/_add_status.blade.php ENDPATH**/ ?>