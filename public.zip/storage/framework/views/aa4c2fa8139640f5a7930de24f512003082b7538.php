<?php $__env->startSection('inc_css'); ?>
<?php $__env->startSection('content'); ?>
<?php
$title=__('formname.profile');
?>

<?php $__env->startSection('title', $title); ?>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($title); ?>

                                    </h3>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <?php if(isset($admin) || !empty($admin)): ?>
                        <?php echo e(Form::model($admin, ['route' => ['profile_update', $admin->id], 'method' => 'PUT','id'=>'m_form_1','class'=>'m-form m-form--fit m-form--label-align-right','autocomplete' => 'off'])); ?>

                        <?php else: ?>
                        <?php echo e(Form::open(array('route' => 'profile_update','method'=>'post','class'=>'m-form m-form--fit m-form--label-align-right','id'=>'m_form_1'))); ?>

                        <?php endif; ?>
                        <div class="m-portlet__body">
                            <div class="m-form__content">
                                
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.first_name').'*', null,array('class'=>'col-form-label
                                col-lg-3
                                col-sm-12')); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('first_name',@$admin->first_name,array('class'=>'form-control
                                    m-input', 'maxlength'=>config('constant.name_length'),'placeholder'=>__('formname.first_name'))); ?>

                                    <?php if($errors->has('first_name')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('first_name')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.last_name') .'*', null,array('class'=>'col-form-label
                                col-lg-3 col-sm-12')); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('last_name',@$admin->last_name,array('class'=>'form-control
                                    m-input', 'maxlength'=>config('constant.name_length'),'placeholder'=>__('formname.last_name'))); ?>

                                    <?php if($errors->has('last_name')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('last_name')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.email'). '*', null,array('class'=>'col-form-label
                                col-lg-3
                                col-sm-12')); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::email('email',@$admin->email,array('class'=>'form-control
                                    m-input', 'maxlength'=>config('constant.email_length'),'placeholder'=>__('formname.email'))); ?>

                                    <span>
                                        <?php if($errors->has('email')): ?> <p style="color:red;">
                                            <?php echo e($errors->first('email')); ?></p> <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                            <?php echo Form::hidden('id',@$admin->id ,['id'=>'id']); ?>

                            <div class="m-portlet__foot m-portlet__foot--fit">
                                <div class="m-form__actions m-form__actions">
                                    <br>
                                    <div class="row">
                                        <div class="col-lg-9 ml-lg-auto">
                                            <?php echo Form::submit(__('formname.submit'), ['class' => 'btn btn-success'] ); ?>

                                            <a href="<?php echo e(route('admin_dashboard')); ?>"
                                                class="btn btn-secondary"><?php echo e(__('formname.cancel')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
    var rule = $.extend({}, <?php echo json_encode(config('constant'), JSON_FORCE_OBJECT); ?>);
</script>
<script src="<?php echo e(asset('backend/js/admin/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/admin/profile.blade.php ENDPATH**/ ?>