<?php $__env->startSection('inc_css'); ?>

<?php $__env->startSection('content'); ?>
<?php
if(isset($user)){
$title=__('formname.user_update');
}
else{
$title=__('formname.user_create');
}
?>

<?php $__env->startSection('title', $title); ?>
<style>
    select {
        width: 100% !important;
        overflow: hidden !important;
        white-space: pre !important;
        text-overflow: ellipsis !important;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <a href="<?php echo e(route('user_index')); ?>"
                                    class="btn btn-secondary m-btn m-btn--air m-btn--custom">
                                    <span>
                                        <i class="la la-arrow-left"></i>
                                        <span><?php echo e(__('formname.back')); ?></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <?php if(isset($user) || !empty($user)): ?>
                        <?php echo e(Form::model($user, ['route' => ['user_store', $user->id], 'method' => 'PUT','id'=>'m_form_1','class'=>'m-form m-form--fit m-form--label-align-right','enctype'=>'multipart/form-data'])); ?>

                        <?php else: ?>
                        <?php echo e(Form::open(['route' => 'user_store','method'=>'POST','class'=>'m-form m-form--fit m-form--label-align-right','id'=>'m_form_1','enctype'=>'multipart/form-data'])); ?>

                        <?php endif; ?>
                        <div class="m-portlet__body">
                            <div class="m-form__content">
                                <div class="m-alert m-alert--icon alert alert-danger m--hide" role="alert"
                                    id="m_form_1_msg">
                                    <div class="m-alert__icon">
                                        <i class="la la-warning"></i>
                                    </div>
                                    <div class="m-alert__text">
                                        <?php echo e(__('admin/messages.required_alert')); ?>

                                    </div>
                                    <div class="m-alert__close">
                                        <button type="button" class="close" data-close="alert" aria-label="Close">
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.first_name').'*', null,['class'=>'col-form-label
                                col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('first_name',isset($user)?$user->first_name:'',['class'=>'form-control
                                    m-input','maxlength'=>config('constant.user_name_length'),'placeholder'=>__('formname.first_name')]); ?>

                                    <?php if($errors->has('first_name')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('first_name')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.last_name') .'*', null,['class'=>'col-form-label
                                col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('last_name',isset($user)?$user->last_name:'',['class'=>'form-control
                                    m-input','maxlength'=>config('constant.user_name_length'),'placeholder'=>__('formname.last_name')]); ?>

                                    <?php if($errors->has('last_name')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('last_name')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <?php if(!isset($user->id)): ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.email'). '*', null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::email('email',isset($user)?$user->email:'',['class'=>'form-control
                                    m-input','maxlength'=>config('constant.email_length'),'placeholder'=>__('formname.email')]); ?>

                                    <span>
                                        <?php if($errors->has('email')): ?> <p style="color:red;">
                                            <?php echo e($errors->first('email')); ?></p> <?php endif; ?>
                                    </span>
                                </div>
                            </div>
                            <?php else: ?>
                                <div class="form-group m-form__group row">
                                    <?php echo Form::label(__('formname.email').'', null,['class'=>'col-form-label col-lg-3
                                    col-sm-12']); ?>

                                    <div class="col-lg-6 col-md-9 col-sm-12 pt-3">
                                        <b><?php echo e(@$user->email); ?></b>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.phone') .'*', null,['class'=>'col-form-label
                                col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('phone',isset($user)?$user->phone:'',['class'=>'form-control
                                    m-input','maxlength'=>config('constant.phone_length'),'placeholder'=>__('formname.phone')]); ?>

                                    <?php if($errors->has('phone')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('phone')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.profile_picture') .'*', null,['class'=>'col-form-label
                                col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::file('image',['id'=>'imgInput','class'=>'form-control m-input','accept' => 'image/*']); ?>

                                    <input type="hidden" name="stored_img_name" id="stored_img_id" value="<?php echo e(@$user->profile_pic); ?>">
                                    <?php if($errors->has('image')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('image')); ?></p>
                                    <?php endif; ?>
                                    <?php if($user): ?>
                                        <img id="blah" src="<?php echo e(@$user->profile_image); ?>" alt="" height="200px;" width="200px;"
                                        style="display:block;" />
                                    <?php else: ?>
                                    <img id="blah" src="" alt="" height="200px;" width="200px;"
                                        style="display:none;" />
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.company.title').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('company_id', @$companyList,@$user->company_id,['id'=>'company_id','class' =>'form-control']); ?>

                                    <?php if($errors->has('company_id')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('company_id')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <?php if(!isset($user->id)): ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.company_position').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('user_type',@$userTypeList,@$user->user_type,['class' => 'form-control', 'id' => 'positionId']); ?>

                                    <?php if($errors->has('user_type')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('user_type')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <?php else: ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.company_position').'', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12 pt-3">
                                    <b><?php echo e(@config('constant.user_types')[$user->user_type]); ?></b>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.role_id').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('role_id',@$subRoleList??[''=>'Select Role'],@$user->role_id,['class' => 'form-control', 'id'=>'roleId']); ?>

                                    <?php if($errors->has('role_id')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('role_id')); ?></p> <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.password').'*', null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <div class="input-group">
                                        <?php echo Form::password('password',['class' =>
                                        'form-control m-input','id'=>'password','type'
                                        =>'password','placeholder'=>__('formname.password'),
                                        'maxlength'=>config('constant.password_max_length'),'minlength'=>config('constant.password_min_length')]); ?>

                                    </div>
                                    <span class="passwordError">
                                        <?php if($errors->has('password')): ?>
                                        <p class="errors"><?php echo e($errors->first('password')); ?></p>
                                        <?php endif; ?>
                                    </span>
                                    <span class="m-form__help"></span>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.confirm_password').'*', null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <div class="input-group">
                                        <?php echo Form::password('confirm_password',['class' =>
                                        'form-control m-input','id'=>'password','type'
                                        =>'confirm_password','placeholder'=>__('formname.confirm_password'),
                                        'maxlength'=>config('constant.password_max_length'),'minlength'=>config('constant.password_min_length')]); ?>

                                    </div>
                                    <span class="conformPasswordError">
                                        <?php if($errors->has('confirm_password')): ?>
                                        <p class="errors"><?php echo e($errors->first('confirm_password')); ?></p>
                                        <?php endif; ?>
                                    </span>
                                    <span class="m-form__help"></span>
                                </div>
                            </div>
                            <?php if(isset($job) && count($job) <= 0): ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.status').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('status', @$statusList, @$userststus,
                                    ['class' =>
                                    'form-control' ]); ?>

                                </div>
                            </div>
                            <?php endif; ?>
                            <?php echo Form::hidden('id',isset($user)?$user->id:'' ,['id'=>'id']); ?>

                            <div class="m-portlet__foot m-portlet__foot--fit">
                                <div class="m-form__actions m-form__actions">
                                    <br>
                                    <div class="row">
                                        <div class="col-lg-9 ml-lg-auto">
                                            <?php echo Form::submit(__('formname.submit'), ['class' => 'btn btn-success'] ); ?>

                                            <a href="<?php echo e(Route('user_index')); ?>"
                                                class="btn btn-secondary"><?php echo e(__('formname.cancel')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
    var rule = $.extend({}, <?php echo json_encode(config('constant'), JSON_FORCE_OBJECT); ?>);
    var formname = $.extend({}, <?php echo json_encode(__('formname'), JSON_FORCE_OBJECT); ?>);
    var id = '<?php echo e(@$user->id); ?>';
    var getRoleUrl = "<?php echo e(route('get-user-role')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/user/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/user/create_user.blade.php ENDPATH**/ ?>