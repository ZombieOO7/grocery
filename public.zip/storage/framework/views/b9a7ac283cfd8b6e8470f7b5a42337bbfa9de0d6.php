<?php if(@$admin->id != 1): ?>
<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="admin_checkbox[]" value="<?php echo e(@$admin->id); ?>" class="m-checkable admin_checkbox checkbox">
    <span></span>
</label>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/admin/_add_checkbox.blade.php ENDPATH**/ ?>