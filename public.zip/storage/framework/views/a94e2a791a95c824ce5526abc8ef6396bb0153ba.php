
<?php echo e(Str::limit(@$category->title, 30)); ?>

<?php if(strlen(@$category->title) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc" data-title="<?php echo e($title); ?>"  data-description="<?php echo e(@$category->title); ?>" data-toggle="modal" data-target="#DescModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/category/_add_message.blade.php ENDPATH**/ ?>