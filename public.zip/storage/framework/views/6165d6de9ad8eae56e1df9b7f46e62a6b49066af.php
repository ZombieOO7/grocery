<!DOCTYPE html>
<html lang="en">
<!-- begin::Head -->

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name', 'Laravel')); ?></title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/favicon@32x32.png')); ?>" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <meta name="csrfToken" id="csrfToken" content="<?php echo e(csrf_token()); ?>">
    <?php $__env->startComponent('admin.includes.headerInc'); ?>
    <?php echo $__env->renderComponent(); ?>
</head>
<!-- end::Head -->
<!-- begin::Body -->

<body
    class="m-page--fluid m--skin- m-content--skin-light2 m-header--fixed m-header--fixed-mobile m-aside-left--enabled m-aside-left--skin-dark m-aside-left--fixed m-aside-left--offcanvas m-footer--push m-aside--offcanvas-default">
    <!-- begin:: Page -->
    <div class="m-grid m-grid--hor m-grid--root m-page">
        <?php $__env->startComponent('admin.includes.header'); ?>
        <?php $__env->slot('title'); ?>
        <?php echo $__env->yieldContent('title'); ?>
        <?php $__env->endSlot(); ?>
        <?php echo $__env->renderComponent(); ?>

        <!-- begin::Body -->
        <div class="m-grid__item m-grid__item--fluid m-grid m-grid--ver-desktop m-grid--desktop m-body">
            <?php $__env->startComponent('admin.includes.sidebar'); ?>
            <?php echo $__env->renderComponent(); ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- end:: Body -->
        <?php $__env->startComponent('admin.includes.footer'); ?>
        <?php echo $__env->renderComponent(); ?>
    </div>
    <!-- end:: Page -->
    <!-- begin::Scroll Top -->
    <div id="m_scroll_top" class="m-scroll-top">
        <i class="la la-arrow-up"></i>
    </div>
    <!-- end::Scroll Top -->
    <?php $__env->startComponent('admin.includes.footerInc'); ?>
    <?php echo $__env->renderComponent(); ?>
</body>
<!-- end::Body -->

</html>
<?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/layouts/default.blade.php ENDPATH**/ ?>