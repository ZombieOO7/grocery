<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', @$title); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/jquery-ui.css')); ?>">
<style>
    .hid_spn{
        display: none !important;
    }
    .imgHeightWidth{
        width: 250px;
        height: 250px;
    }
</style>
<style>
    .commonSelect {
        width: 100% !important;
        overflow: hidden !important;
        white-space: pre !important;
        text-overflow: ellipsis !important;
    }
    .ui-autocomplete {
    max-height: 100px;
    overflow-y: auto;
    /* prevent horizontal scrollbar */
    overflow-x: hidden;
  }
  /* IE 6 doesn't support max-height
   * we use height instead, but this forces the menu to always be this tall
   */
  * html .ui-autocomplete {
    height: 100px;
  }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e(@$title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <a href="<?php echo e(route('product.index')); ?>"
                                    class="btn btn-secondary m-btn m-btn--air m-btn--custom">
                                    <span>
                                        <i class="la la-arrow-left"></i>
                                        <span><?php echo e(__('formname.back')); ?></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <?php if(isset($product) || !empty($product)): ?>
                        <?php echo e(Form::model($product, ['route' => ['product.store', @$product->uuid], 'method' => 'PUT','id'=>'m_form_1','class'=>'m-form m-form--fit m-form--label-align-right','files' => true,'autocomplete' => "off"])); ?>

                        <?php else: ?>
                        <?php echo e(Form::open(['route' => 'product.store','method'=>'post','class'=>'m-form m-form--fit m-form--label-align-right','id'=>'m_form_1','files' => true,'autocomplete' => "off"])); ?>

                        <?php endif; ?>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.product.title').'*', null,['class'=>'col-form-label
                                col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('title',@$product->title,['id'=>'names','class'=>'form-control
                                    m-input err_msg','maxlength'=>config('constant.name_length'),'placeholder'=>__('formname.product.title')]); ?>

                                    <?php if($errors->has('title')): ?>
                                        <p style="color:red;"><?php echo e($errors->first('title')); ?></p> 
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label('category_id',__('formname.category.list')." <sup
                                    class='rqvr'>*</sup>" ,['class'=>'col-form-label col-lg-3
                                col-sm-12'],false); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('category_id', @$categoryList, @$product->category_id,
                                    ['id' => 'category_id','class' =>'form-control selectpicker','placeholder' => __('formname.select')]); ?>

                                </div>
                            </div>
                            
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.image').'*', null,['class'=>'col-form-label
                                col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12 img_msg_scn">
                                    <div class="input-group err_msg">
                                        <?php echo Form::file('images[]', ['class'=>'custom-file-input' ,'id'=>'imgInp2',
                                        'accept' => 'image/*','multiple'=>true]); ?>

                                        <?php echo Form::label('Choose file', null,['class'=>'custom-file-label']); ?>

                                        <input type="hidden" name="stored_image" id="stored_img_id"
                                            value="<?php echo e(@$product->image); ?>">
                                        </br>
                                        <?php if($errors->has('image')): ?> <p style="color:red;">
                                            <?php echo e($errors->first('image')); ?></p> <?php endif; ?>
                                    </div>
                                    <?php if($errors->has('imgInp')): ?>
                                    <p style="color:red;">
                                        <?php echo e($errors->first('imgInphttps://docs.google.com/spreadsheets/d/1sVtcgp0Or_ujHYnwbMewkmecymD6UJfe/edit#gid=251971411')); ?>

                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row" id="blah">
                                <div class="col-form-label col-lg-3 col-sm-12"></div>
                                <div class="col-lg-6 col-md-9 col-sm-12 row dynamicImages">
                                    <?php $__empty_1 = true; $__currentLoopData = @$product->productMedia??[]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class='col-md-6'>
                                        <img class="imgHeightWidth" src="<?php echo e($media->attachment->image_path); ?>" alt="" style="display:block;" />
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.product.short_description').'*', null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <div class="input-group">
                                        <?php echo Form::textarea('short_description',@$product->short_description,['class'=>'form-control
                                        m-input do-not-ignore']); ?>

                                    </div>
                                    <span class="shortDescriptionError">
                                        <?php if($errors->has('short_description')): ?> <p class='errors' style="color:red;">
                                            <?php echo e($errors->first('short_description')); ?></p>
                                        <?php endif; ?>
                                    </span>
                                    <span class="m-form__help"></span>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.product.price').'*', null,['class'=>'col-form-label
                                col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::text('price',@$product->price,['id'=>'names','class'=>'form-control
                                    m-input err_msg','maxlength'=>config('constant.name_length'),'placeholder'=>__('formname.product.price')]); ?>

                                    <?php if($errors->has('title')): ?>
                                        <p style="color:red;"><?php echo e($errors->first('title')); ?></p> 
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.product.description').'*', null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <div class="input-group">
                                        <?php echo Form::textarea('description',@$product->description,['class'=>'form-control
                                        m-input do-not-ignore','id'=>'editor1']); ?>

                                    </div>
                                    <span class="descriptionError">
                                        <?php if($errors->has('description')): ?> <p class='errors' style="color:red;">
                                            <?php echo e($errors->first('description')); ?></p>
                                        <?php endif; ?>
                                    </span>
                                    <span class="m-form__help"></span>
                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.product.stock_status').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('stock_status', @$stockStatusList, @$product->stock_status,
                                    ['class' =>
                                    'form-control' ]); ?>

                                </div>
                            </div>
                            <div class="form-group m-form__group row">
                                <?php echo Form::label(__('formname.status').'*', null,['class'=>'col-form-label col-lg-3
                                col-sm-12']); ?>

                                <div class="col-lg-6 col-md-9 col-sm-12">
                                    <?php echo Form::select('status', @$statusList, @$product->status,
                                    ['class' =>
                                    'form-control' ]); ?>

                                </div>
                            </div>
                            <?php echo Form::hidden('id',@$product->id ,['id'=>'id']); ?>

                            <div class="m-portlet__foot m-portlet__foot--fit">
                                <div class="m-form__actions m-form__actions">
                                    <br>
                                    <div class="row">
                                        <div class="col-lg-9 ml-lg-auto">
                                            <?php echo Form::submit(__('formname.submit'), ['class' => 'btn btn-success'] ); ?>

                                            <a href="<?php echo e(Route('product.index')); ?>"
                                                class="btn btn-secondary"><?php echo e(__('formname.cancel')); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<script>
    $(document).find('#category_id').selectpicker({  
        placeholder: "Select Category",
        allowClear: true
    })
    // $(document).find('#sub_category_id').selectpicker({  
    //     placeholder: "Select Category",
    //     allowClear: true
    // }) 
    // $(document).find("#paper_category").select2();
</script>
<script src="<?php echo e(asset('js/jquery-ui.js')); ?>"></script>
<script>
var rule = $.extend({}, <?php echo json_encode(config('constant'), JSON_FORCE_OBJECT); ?>);
var formname = $.extend({}, <?php echo json_encode(__('formname'), JSON_FORCE_OBJECT); ?>);
var id = '<?php echo e(@$user->id); ?>';
var url = "<?php echo e(route('product.datatable')); ?>";
var getSubCat = "<?php echo e(route('get-sub-cat-list')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/product/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/product/create.blade.php ENDPATH**/ ?>