    <a class=" view" data-job_url="<?php echo e(route('problem.jobstatus')); ?>" href="<?php echo e(URL::signedRoute('problem.edit',['uuid'=>@$problem->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" data-job_url="<?php echo e(route('problem.jobstatus')); ?>" href="javascript:;" id="<?php echo e(@$problem->uuid); ?>" data-table_name="problem_table" data-url="<?php echo e(route('problem.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$problem->status=='1'): ?>
        <a class=" active_inactive" data-job_url="<?php echo e(route('problem.jobstatus')); ?>" href="javascript:;" id="<?php echo e(@$problem->uuid); ?>" data-url="<?php echo e(route('problem.active_inactive', [@$problem->id])); ?>" data-table_name="problem_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" data-job_url="<?php echo e(route('problem.jobstatus')); ?>" href="javascript:;" id="<?php echo e(@$problem->uuid); ?>" data-url="<?php echo e(route('problem.active_inactive', [@$problem->id])); ?>" data-table_name="problem_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/problem/_add_action.blade.php ENDPATH**/ ?>