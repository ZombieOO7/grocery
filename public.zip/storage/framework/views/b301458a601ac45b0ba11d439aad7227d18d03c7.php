<?php if(@$admin->id != '1'): ?>
<?php if((\Auth::guard('admin')->user()->can('admin edit'))): ?>
<a class=" view" href="<?php echo e(URL::signedRoute('admin_edit',['id'=>@$admin->id])); ?>" title="Edit Admin"><i
        class="fas fa-pencil-alt"></i></a>
<?php endif; ?>
<?php if((\Auth::guard('admin')->user()->can('admin delete'))): ?>
<a class="delete" href="javascript:;" id="<?php echo e(@$admin->id); ?>" data-table_name="admin_table"
    data-url="<?php echo e(route('admin_delete')); ?>" title="Delete Admin"><i class="fas fa-trash-alt"></i>
</a>
<?php endif; ?>
<?php if((\Auth::guard('admin')->user()->can('admin active inactive'))): ?>
<?php if(@$admin->status=='1'): ?>
<a class=" active_inactive" href="javascript:;" id="<?php echo e(@$admin->id); ?>"  data-url="<?php echo e(route('admin_active_inactive', [@$admin->id])); ?>" data-table_name="admin_table" title="Active Admin"><i class="fas fa-toggle-on"></i>
</a>
<?php else: ?>
<a class=" active_inactive" href="javascript:;" id="<?php echo e(@$admin->id); ?>" data-url="<?php echo e(route('admin_active_inactive', [@$admin->id])); ?>" data-table_name="admin_table" title="Inactive Admin"><i
        class="fas fa-toggle-off"></i>
</a>
<?php endif; ?>
<?php endif; ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/admin/_add_action.blade.php ENDPATH**/ ?>