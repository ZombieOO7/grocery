
<?php echo e(Str::limit(@$contact->message, 30)); ?>

<?php if(strlen(@$contact->message) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc" data-subject="<?php echo e(@$contact->subject); ?>" data-description="<?php echo e(@$contact->message); ?>" data-toggle="modal" data-target="#DescModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/contact-us/_add_message.blade.php ENDPATH**/ ?>