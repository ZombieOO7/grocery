<?php $__env->startSection('inc_css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.3/css/bootstrap-colorpicker.min.css"
    rel="stylesheet">
<style>
    label {
        font-weight: 600;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
if(isset($job)){
$title=__('formname.job.detail');
}
else{
$title=__('formname.job.detail');
}
if(URL::previous() == Request::fullUrl()){
    $backurl = route('job.index');
}else{
    $backurl = URL::previous();
}
?>

<?php $__env->startSection('title', $title); ?>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <a href="<?php echo e($backurl); ?>"
                                    class="btn btn-secondary m-btn m-btn--air m-btn--custom">
                                    <span>
                                        <i class="la la-arrow-left"></i>
                                        <span>Back</span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        
                        
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.machine').' : ', null,['class'=>'col-form-label
                            col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->machine->title); ?>

                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.location').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->location->title); ?>

                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.problem').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->problem->title); ?>

                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.requested_by').' : ', null,['class'=>'col-form-label
                            col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->created_by_text); ?>

                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.assigned_to').' : ', null,['class'=>'col-form-label
                            col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-3 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->assignedTo->full_name_text); ?>

                                
                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.comment').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo @$job->comment; ?>

                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.priority').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            
                            <div class="col-lg-3 col-md-9 col-sm-12">
                                <?php echo Form::select('priority', @$jobPriorityList, @$job->priority,
                                ['class' => 'form-control', 'id'=>'priority', 'data-id'=>@$job->uuid ,'data-url'=>route('job.change.priority') ]); ?>

                                <?php if($errors->has('priority')): ?>
                                <p style="color:red;"><?php echo e($errors->first('priority')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.job_status').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label" style="color:<?php echo e(@config('constant.job_status_color')[$job->job_status_id]); ?>">
                                <?php echo e(@config('constant.job_status_text')[$job->job_status_id]); ?>

                            </div>
                        </div>
                        <?php if($jobImages): ?>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.images').' : ',
                            null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label" style='display:contents'>
                                <?php $__empty_1 = true; $__currentLoopData = $jobImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div style="margin-left:5px;" id="job-<?php echo e($key); ?>">
                                    <img id="blah" src="<?php echo e(@$image->job_image); ?>" alt="" height="100px;" width="100px;"
                                        style="display:block;" />
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php else: ?>
                        <img id="blah" src="" alt="" height="100px;" width="100px;" style="display:none;" />
                        <?php endif; ?>
                        
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.job_hours').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->total_job_duration); ?>

                            </div>
                        </div>
                        <?php if($job->job_status_id == 5): ?>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.decline_reason').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->reason); ?>

                            </div>
                        </div>
                        <?php endif; ?>
                        <?php if($job->job_status_id == 7): ?>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.incomplete_reason').' : ',
                            null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->incomplete_reason); ?>

                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script src="<?php echo e(asset('backend/js/job/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/job/detail.blade.php ENDPATH**/ ?>