
<?php echo e(Str::limit(@$problem->title, 30)); ?>

<?php if(strlen(@$problem->title) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc" data-description="<?php echo e(@$problem->title); ?>" data-toggle="modal" data-target="#DescModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/problem/_add_message.blade.php ENDPATH**/ ?>