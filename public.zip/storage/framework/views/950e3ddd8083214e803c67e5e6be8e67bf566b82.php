<?php
$routeName = Route::currentRouteName();
?>
<!-- BEGIN: Left Aside -->
<button class="m-aside-left-close  m-aside-left-close--skin-dark " id="m_aside_left_close_btn">
    <i class="la la-close"></i>
</button>
<div id="m_aside_left" class="m-grid__item	m-aside-left  m-aside-left--skin-dark ">
    <!-- BEGIN: Aside Menu -->
    <div id="m_ver_menu" class="m-aside-menu  m-aside-menu--skin-dark m-aside-menu--submenu-skin-dark " m-menu-vertical="1"
        m-menu-scrollable="1" m-menu-dropdown-timeout="500" style="position: relative;">
        <ul class="m-menu__nav  m-menu__nav--dropdown-submenu-arrow side_bar">
            <li class="m-menu__item  <?php if($routeName == 'admin_dashboard'): ?> m-menu__item--active <?php endif; ?>"
                aria-haspopup="true">
                <a href="<?php echo e(route('admin_dashboard')); ?>" class="m-menu__link ">
                    <i class="m-menu__link-icon fa 	fa-tv"></i>
                    <span class="m-menu__link-title">
                        <span class="m-menu__link-wrap">
                            <span class="m-menu__link-text"><?php echo e(__('formname.dashboard')); ?></span>
                        </span>
                    </span>
                </a>

            </li>
            <li class="m-menu__item  m-menu__item--submenu 
                    <?php if($routeName == 'cms_index' ||$routeName == 'cms_create' ||$routeName == 'cms_edit' ||
                        $routeName == 'category.index' || $routeName == 'category.create' || $routeName == 'category.edit' ||
                        $routeName == 'subcategory.index' || $routeName == 'subcategory.create' || $routeName == 'subcategory.edit' ||
                        $routeName == 'banner.index' || $routeName == 'banner.create' || $routeName == 'banner.edit'
                        ): ?> m-menu__item--active m-menu__item--open <?php endif; ?> "
                    aria-haspopup="true" m-menu-submenu-toggle="hover">
                    <a href="javascript:;" class="m-menu__link m-menu__toggle">
                        <i class="m-menu__link-icon flaticon-layers"></i>
                        <span class="m-menu__link-text"><?php echo e(__('formname.masters')); ?></span>
                        <i class="m-menu__ver-arrow la la-angle-right"></i>
                    </a>
                    <!-- CMS Management -->
                    
                    <!-- Category Management -->
                    <div class="m-menu__submenu ">
                        <span class="m-menu__arrow"></span>
                        <ul class="m-menu__subnav">
                            <li class="m-menu__item <?php if($routeName == 'category.index' || $routeName == 'category.create' || $routeName == 'category.edit'): ?> m-menu__item--active <?php endif; ?>"
                                aria-haspopup="true">
                                <a href="<?php echo e(route('category.index')); ?>" class="m-menu__link">
                                    <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                                        <span></span>
                                    </i>
                                    <span class="m-menu__link-text"><?php echo e(__('formname.category.label')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Sub Category Management -->
                    
                    <!-- Banner Management -->
                    <div class="m-menu__submenu ">
                        <span class="m-menu__arrow"></span>
                        <ul class="m-menu__subnav">
                            <li class="m-menu__item <?php if($routeName == 'banner.index' || $routeName == 'banner.create' || $routeName == 'banner.edit'): ?> m-menu__item--active <?php endif; ?>"
                                aria-haspopup="true">
                                <a href="<?php echo e(route('banner.index')); ?>" class="m-menu__link">
                                    <i class="m-menu__link-bullet m-menu__link-bullet--dot">
                                        <span></span>
                                    </i>
                                    <span class="m-menu__link-text"><?php echo e(__('formname.banner.label')); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                    <!-- Faq Management -->
                    
                    <!-- Email Template Management -->
                    
                </li>
            
            <li class="m-menu__item  <?php if($routeName == 'product.index' || $routeName == 'product.create' ||$routeName == 'product.edit'): ?> m-menu__item--active <?php endif; ?>"
            aria-haspopup="true">
                    <a href="<?php echo e(route('product.index')); ?>" class="m-menu__link ">
                        <i class="m-menu__link-icon flaticon-cart "></i>
                        <span class="m-menu__link-title">
                            <span class="m-menu__link-wrap">
                                <span class="m-menu__link-text"><?php echo e(__('formname.product.label')); ?></span>
                            </span>
                        </span>
                    </a>
                </li>

            
            
            <li class="m-menu__item  <?php if($routeName == 'profile'): ?> m-menu__item--active <?php endif; ?>"
                aria-haspopup="true">
                <a href="<?php echo e(route('profile')); ?>" class="m-menu__link ">
                    <i class="m-menu__link-icon 
            flaticon-profile "></i>
                    <span class="m-menu__link-title">
                        <span class="m-menu__link-wrap">
                            <span class="m-menu__link-text"><?php echo e(__('formname.profile')); ?></span>
                        </span>
                    </span>
                </a>
            </li>
            <li class="m-menu__item " aria-haspopup="true">
                <a href="<?php echo e(route('admin.logout')); ?>"
                    onclick="event.preventDefault(); document.getElementById('frm-side-logout').submit();"
                    class="m-menu__link">
                    <i class="m-menu__link-icon fa 	fa-sign-out-alt"></i>
                    <span class="m-menu__link-text">Logout</span>
                </a>
                <form id="frm-side-logout" action="<?php echo e(route('admin.logout')); ?>" method="post"
                    style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
    </div>
    <!-- END: Aside Menu -->
</div>
<!-- END: Left Aside -->
<?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>