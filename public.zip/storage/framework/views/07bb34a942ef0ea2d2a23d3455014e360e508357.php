    <a class=" view" href="<?php echo e(URL::signedRoute('subcategory.edit',['uuid'=>@$subCategory->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" href="javascript:;" id="<?php echo e(@$subCategory->uuid); ?>" data-table_name="sub_category_table" data-url="<?php echo e(route('subcategory.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$subCategory->status=='1'): ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$subCategory->uuid); ?>" data-url="<?php echo e(route('subcategory.active_inactive', [@$subCategory->id])); ?>" data-table_name="sub_category_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$subCategory->uuid); ?>" data-url="<?php echo e(route('subcategory.active_inactive', [@$subCategory->id])); ?>" data-table_name="sub_category_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/sub-category/_add_action.blade.php ENDPATH**/ ?>