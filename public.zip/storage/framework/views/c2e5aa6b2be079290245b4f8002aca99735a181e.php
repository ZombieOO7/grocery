<?php $__env->startSection('content'); ?>
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->startSection('title', __('formname.cms_list')); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <!-- END: Subheader -->
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-portlet m-portlet--mobile">

            <div class="m-portlet__body">
                <div class="m-form__content">
                    <h5><?php echo e(__('formname.cms_list')); ?></h5>
                </div>
                <hr>
                <div class="m-portlet__head" style="padding: 0 !important;">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            
                            
                                  <button class="btn btn-info" style='' id='clr_filter'
                                data-table_name="cms_table"><?php echo e(__('formname.clear_filter')); ?></button>
                        </div>
                    </div>
                    
                </div>
                <!--begin: Datatable -->
                <table class="table table-striped- table-bordered table-hover table-checkable" id="cms_table">
                    <thead>
                        <tr>
                            
                            
                            <th><?php echo e(__('formname.title')); ?></th>
                            <th><?php echo e(__('formname.created_at')); ?></th>
                            
                            <th><?php echo e(__('formname.action')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            
                            
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.title')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.created_at')); ?>"></th>
                          
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php /*Load script to footer section*/?>

<?php $__env->startSection('inc_script'); ?>
<script>
var cms_list_url = "<?php echo e(route('cms_datatable')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/cms/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/cms/index.blade.php ENDPATH**/ ?>