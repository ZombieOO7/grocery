<?php $__env->startPush('inc_css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->startSection('title', 'Dashboard'); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper adminDashboard">
    <!-- BEGIN: Subheader -->
    <div class="m-subheader ">
        <div class="d-flex align-items-center" >
            <div class="mr-auto">
                <h3 class="m-subheader__title ">Dashboard</h3>
            </div>
        </div>
    </div>
    <div class="m-content " style="padding-left:15px !important;" >
        <div class="col-md-12">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="dashboard-stat blue-madison">
                        <div class="visual">
                            <i class="flaticon-user"></i>
                        </div>
                        <div class="details">
                            <div class="number">
                                <?php echo e($totalUsers ?? 0); ?>

                            </div>
                            <div class="desc">
                                <?php echo e(__('formname.dashboard_array.total_users')); ?> <i
                                    class="m-icon-swapright m-icon-white"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="m-grid__item m-grid__item--fluid m-wrapper">
        <div class="m-content ">
            <div class="m-portlet m-portlet--mobile">
                <div class="m-portlet__body">
                    <div class="m-form__content">
                        <h5><?php echo e(__('formname.dashboard_array.job_list')); ?></h5>
                    </div>
                    <hr>
                    <table class="table table-striped- table-bordered table-hover table-checkable for_wdth "
                        id="job_table" data-type="" data-url="<?php echo e(route('job.datatable')); ?>">
                        <thead>
                            <tr>
                                
                                <th><?php echo e(__('formname.job.machine')); ?></th>
                                <th><?php echo e(__('formname.job.problem')); ?></th>
                                <th><?php echo e(__('formname.job.location')); ?></th>
                                <th><?php echo e(__('formname.job.requested_by')); ?></th>
                                <th><?php echo e(__('formname.job.priority')); ?></th>
                                <th><?php echo e(__('formname.job.job_status')); ?></th>
                                <th><?php echo e(__('formname.created_at')); ?></th>
                                <th><?php echo e(__('formname.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                
                                <td><?php echo truncateString(__('formname.machine.title'),@$job->machine); ?></td>
                                <td><?php echo truncateString(__('formname.problem.title'),@$job->problem); ?></td>
                                <td><?php echo truncateString(__('formname.location.title'),@$job->location); ?></td>
                                <td><?php echo e(@$job->created_by_text); ?></td>
                                <td>
                                    
                                    <span class="m-badge  m-badge--<?php echo e(@config('constant.priorites_colors')[$job->priority]); ?> m-badge--wide"><?php echo e(@config('constant.priorites')[$job->priority]); ?></span>
                                </td>
                                <td>
                                    <span class="" style="color:<?php echo e(@config('constant.job_status_color')[$job->job_status_id]); ?>">
                                        <?php echo e(@config('constant.job_status_text')[$job->job_status_id]); ?>

                                    </span>
                                </td>
                                <td><?php echo @$job->proper_created_at; ?></td>
                                <td><a class="detail" href="<?php echo e(URL::signedRoute('job.detail',['uuid'=>@$job->uuid])); ?>" id="<?php echo e(@$job->id); ?>" data-table_name="job_table" title="Detail"><i class="fas fa-eye"></i>
                                </a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center">No jobs found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="m-portlet m-portlet--mobile">
                <div class="m-portlet__body">
                    <div class="m-form__content">
                        <h5><?php echo e(__('formname.dashboard_array.waiting_for_confirm')); ?></h5>
                    </div>
                    <hr>
                    <table class="table table-striped- table-bordered table-hover table-checkable for_wdth"
                        id="job_table" data-type="" data-url="<?php echo e(route('job.datatable')); ?>">
                        <thead>
                            <tr>
                                <th><?php echo e(__('formname.first_name')); ?></th>
                                <th><?php echo e(__('formname.last_name')); ?></th>
                                <th><?php echo e(__('formname.email')); ?></th>
                                <th><?php echo e(__('formname.phone')); ?></th>
                                <th><?php echo e(__('formname.company.title')); ?></th>
                                <th><?php echo e(__('formname.company_position')); ?></th>
                                <th><?php echo e(__('formname.created_at')); ?></th>
                                <th><?php echo e(__('formname.status')); ?></th>
                                <th><?php echo e(__('formname.action')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(@$user->first_name); ?></td>
                                <td><?php echo e(@$user->last_name); ?></td>
                                <td><?php echo e(@$user->email); ?></td>
                                <td><?php echo e(@$user->phone); ?></td>
                                <td><?php echo e(@$user->company->title); ?></td>
                                <td><?php echo e(@config('constant.user_types')[$user->user_type]); ?></td>
                                <td><?php echo @$user->proper_created_at; ?></td>
                                <td><?php echo @$user->active_tag; ?></td>
                                <td><a class=" detail" href="<?php echo e(URL::signedRoute('user_detail',['id'=>@$user->id])); ?>" id="<?php echo e(@$user->id); ?>" data-table_name="user_table" title="Delete User"><i class="fas fa-eye"></i>
                                </a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">No users found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="m-portlet m-portlet--full-height ">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        Work Order By Location
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="m-portlet__body">
                            <div class="m-form__section m-form__section--first">
                                <?php echo e(Form::open(['method'=>'POST','class'=>'m-form m-form--fit','id'=>'m_form_1'])); ?>

                                    <div class="col-md-12 row">
                                        <div class="col-md-3">
                                            <?php echo Form::label(__('formname.job.location').'*', null,['class'=>'col-form-label']); ?>

                                            <div class="">
                                                <?php echo Form::select('location_id', @$locationList, null,
                                                ['readonly'=>true,'class' => 'form-control','style'=>'border-radius:0px !important;' ,'id'=>'location_id']); ?>

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <?php echo Form::label('From '.'*', null,['class'=>'col-form-label']); ?>

                                            <div class="">
                                                <?php echo Form::text('from_month', null,
                                                ['readonly'=>true,'class' => 'form-control','style'=>'border-radius:0px !important;' ,'id'=>'from_month']); ?>

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <?php echo Form::label('To '.'*', null,['class'=>'col-form-label']); ?>

                                            <div class="">
                                                <?php echo Form::text('to_month', null,
                                                ['readonly'=>true,'class' => 'form-control','style'=>'border-radius:0px !important;' ,'id'=>'to_month']); ?>

                                            </div>
                                        </div>
                                        <div class="col-md-3 mt-3">
                                            <div class='col-form-label'></div>
                                            <?php echo Form::button(__('formname.submit'), ['id'=>'workOrderByLocation', 'class' => 'btn btn-success'] ); ?>

                                        </div>
                                    </div>
                                <?php echo Form::close(); ?>

                            </div>
                            <div class="m-separator m-separator--dashed m-separator--lg"></div>
                            <div class="m-widget13" id="stackedColumnchart" >
                                <div class="m-form__section m-form__section--first">
                                    <div class="form-group m-form__group col-md-12 text-center">
                                        <div class="col-form-label">Select the filter to see the graph results here</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="m-portlet m-portlet--full-height ">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        Work Order Completed By Fitter
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="m-portlet__body">
                            <div class="m-form__section m-form__section--first">
                                <?php echo e(Form::open(['route' => 'report.generate','method'=>'POST','class'=>'m-form m-form--fit','id'=>'m_form_2'])); ?>

                                <div class="col-md-12 row">
                                    <div class="col-md-3">
                                        <?php echo Form::label('Staff *', null,['class'=>'col-form-label']); ?>

                                        <div class="">
                                            <?php echo Form::select('assigned_to', @$engineerList, null,
                                            ['class' => 'form-control','style'=>'border-radius:0px !important;' ,'id'=>'assigned_to']); ?>

                                        </div>
                                    </div>
                                    <div class="col-md-3  mt-3">
                                        <div class='col-form-label'></div>
                                        <?php echo Form::button(__('formname.submit'), ['id'=>'workOrderByFilter', 'class' => 'btn btn-success'] ); ?>

                                    </div>
                                </div>
                                <?php echo Form::close(); ?>

                            </div>
                            <div class="m-separator m-separator--dashed m-separator--lg"></div>
                            <div class="m-widget13" id="columnchart" >
                                <div class="m-form__section m-form__section--first">
                                    <div class="form-group m-form__group col-md-12 text-center">
                                        <div class="col-form-label">Select the filter to see the graph results here</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl-12">
                    <div class="m-portlet m-portlet--full-height ">
                        <div class="m-portlet__head">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        Machine Summary
                                    </h3>
                                </div>
                            </div>
                        </div>
                        <div class="m-portlet__body">
                            <div class="m-form__section m-form__section--first">
                                <div class="m-form__section m-form__section--first">
                                    <?php echo e(Form::open(['route' => 'report.generate','method'=>'POST','class'=>'m-form m-form--fit','id'=>'m_form_3'])); ?>

                                    <div class="col-md-12 row">
                                        <div class="col-md-3">
                                            <?php echo Form::label(__('formname.job.location').'*', null,['class'=>'col-form-label']); ?>

                                            <div class="">
                                                <?php echo Form::select('machine_location_id', @$locationList, null,
                                                ['class' => 'form-control','style'=>'border-radius:0px !important;' ,'id'=>'machine_location_id']); ?>

                                            </div>
                                        </div>
                                        <div class="col-md-3 mt-3">
                                            <div class="col-form-label"></div>
                                            <?php echo Form::button(__('formname.submit'), ['class' => 'btn btn-success','id'=>'machineSummuryReport'] ); ?>

                                        </div>
                                    </div>
                                    <?php echo Form::close(); ?>

                                </div>
                            </div>
                            <div class="m-separator m-separator--dashed m-separator--lg"></div>
                            <div class="m-widget13" id="machineSummuryChart" >
                                <div class="m-form__section m-form__section--first">
                                    <div class="form-group m-form__group col-md-12 text-center">
                                        <div class="col-form-label">Select the filter to see the graph results here</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<!-- Show Description Modal -->
<div class="modal fade def_mod dtails_mdl" id="DescModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content ">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            <div class="modal-body">
                <h3 class="mdl_ttl"></h3>
                <p class="mrgn_tp_20 show_desc" style="word-wrap: break-word;">
                </p>
                <button type="button" class="btn btn-success pull-right" data-dismiss="modal"><?php echo e(__('formname.close')); ?></button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>
<script src="<?php echo e(asset('backend/js/dashboard/index.js')); ?>"></script>
<script>
    var locationUrl = "<?php echo e(route('order-by-location')); ?>";
    $(document).on('click','.shw-dsc',function(e) {
        $(document).find('.show_desc').html($(this).attr('data-description'));
        $(document).find('.mdl_ttl').html($(this).attr('data-title'));
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>