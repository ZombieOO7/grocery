
<?php echo e(Str::limit(@$product->title, 30)); ?>

<?php if(strlen(@$product->title) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc" data-title="<?php echo e($title); ?>"  data-description="<?php echo e(@$product->title); ?>" data-toggle="modal" data-target="#DescModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/product/_add_message.blade.php ENDPATH**/ ?>