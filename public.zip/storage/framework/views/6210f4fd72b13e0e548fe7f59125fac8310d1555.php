<?php
$setting = getWebSetting();
?>
<!--begin::Base Scripts -->
<script src="<?php echo e(asset('backend/dist/default/assets/vendors/base/vendors.bundle.js')); ?>" type="text/javascript">
</script>
<script src="<?php echo e(asset('backend/dist/default/assets/demo/default/base/scripts.bundle.js')); ?>"
    type="text/javascript"></script>
<!--end::Base Scripts -->
<!--begin::Page Vendors -->
<!--end::Page Vendors -->
<!--begin::Page Snippets -->
<script src="<?php echo e(asset('backend/dist/default/assets/app/js/dashboard.js')); ?>" type="text/javascript"></script>
<!--end::Page Snippets -->

<script src="<?php echo e(asset('backend/dist/default/assets/vendors/custom/datatables/datatables.bundle.js')); ?>"
    type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.raty.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/common.js')); ?>" type="text/javascript"></script>
<?php if(isset($setting) && $setting->notify == 1): ?>
<script src="<?php echo e(asset('js/pusher.min.js')); ?>"></script>
<?php endif; ?>

<?php
    $notifications = webNotificationData();
    $totalNotification = count($notifications);
    $updateNotification = route('notification.update');
    $appKey = env('PUSHER_APP_KEY');
    $cluster = env('PUSHER_APP_CLUSTER');
?>
<script>
//Ajax Loader
var updateNotification = '<?php echo e($updateNotification); ?>';
var appKey = '<?php echo e(@$appKey); ?>';
var cluster = '<?php echo e($cluster); ?>';
$(document).ready(function() {
    $(document).ajaxStart(function() {
        $(document).find('.main_loader').show();
    }).ajaxStop(function() {
        $(document).find('.fixedStar').raty({
            readOnly: true,
            path: base_url + '/images',
            starOff: 'small-star-off.png',
            starOn: 'small-star-on.png',
            half: true,
            start: $(document).find(this).attr('data-score')
        });
        $(document).find('.main_loader').hide();
    });
});
/* notification bell */
var notificationData = $.extend({}, <?php echo json_encode($notifications, JSON_FORCE_OBJECT); ?>);
var notificationsWrapper   = $('.m-dropdown__wrapper');
var notificationsCountElem = $(document).find('#data-count');
var notificationsCount     = parseInt('<?php echo e($totalNotification); ?>');//parseInt(notificationsCountElem.data('count'));
var notifications          = notificationsWrapper.find('topbar_notifications_notifications');
if (notificationsCount <= 0) {
}else{
    totalNotification = parseInt('<?php echo e($totalNotification); ?>');
    getContent(notificationData,totalNotification);
}

/*  */

<?php if(isset($setting) && $setting->notify == 1): ?>
var pusher = new Pusher(appKey, {
    cluster: cluster,
    forceTLS: true,
    encrypted: true
});

var channel = pusher.subscribe('get-notification');
channel.bind('App\\Events\\GetNotification', function(data) {
    getContent(data.notifications,data.totalNotification);
});
<?php endif; ?>
</script>
<script src="<?php echo e(asset('sweetalert/sweetalert.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(str_replace('public/', '', URL('resources/lang/js/en/message.js'))); ?>"></script>
<?php echo $__env->yieldContent('inc_script'); ?>
<?php $__env->startComponent('vendor.sweetalert.view'); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/includes/footerInc.blade.php ENDPATH**/ ?>