    <a class=" view" href="<?php echo e(URL::signedRoute('emailTemplate.edit',['id'=>$emailTemplate->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>

    
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/email-template/_add_action.blade.php ENDPATH**/ ?>