<?php
    // dd($groups);
?>
<ul class="left_menu">
    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li groupId='<?php echo e($group->id); ?>' data-unread-count="<?php echo e(@$group['un_read_message_count']); ?>"
    class="<?php echo e(((@$id==$group->id))?'active':''); ?>" userIds='<?php echo e(json_encode($group['user_ids'])); ?>'>
        <div class="time-name">
            <h2 class="responderName_3407065"><?php echo e(@$group->name); ?></h2>
            <h2></h2>
            <p><?php echo e(isset($group['message']['created_at'])?$group['message']['created_at']:''); ?></p>
        </div>
        <h3></h3>
        <div class="counting_text">
            
                <p><?php echo e(isset($group['message']['message'])?$group['message']['message']:''); ?></p>
            
            <?php if($group->un_read_message_count > 0): ?>
            <span class="counter_time"><?php echo e(@$group['un_read_message_count']); ?></span>
            <?php endif; ?>
        </div>
    </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
</ul><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/chat/sidebar2.blade.php ENDPATH**/ ?>