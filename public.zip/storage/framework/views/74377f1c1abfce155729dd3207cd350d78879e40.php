<div class="input-group err_msg">
    <?php if(@$banner->image != null): ?>
        <img id="blah" src="<?php echo e(@$banner->attachment->image_path); ?>" alt="" max-width="200" width="200" height="200"
            style="<?php echo e(isset($banner->image) ? 'display:block;' : 'display:none;'); ?>" />
    <?php else: ?>
        <img id="blah" src="<?php echo e(url('storage/app/public/uploads/' . @$banner->image)); ?>" alt="" width="200"
            max-width="200" height="200" style="<?php echo e(isset($banner->image) ? 'display:block;' : 'display:none;'); ?>" />
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/banner/_add_print.blade.php ENDPATH**/ ?>