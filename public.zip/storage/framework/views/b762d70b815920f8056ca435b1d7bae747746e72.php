<a class=" view" href="<?php echo e(URL::signedRoute('machine.print',['uuid'=>@$machine->uuid])); ?>" title="Print Qr Code">
    <i class="fas fa-print"></i>
</a>
<?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/category/_add_print.blade.php ENDPATH**/ ?>