<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="trade_checkbox[]" value="<?php echo e(@$subCategory->id); ?>" class="m-checkable trade_checkbox checkbox">
    <span></span>
</label><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/sub-category/_add_checkbox.blade.php ENDPATH**/ ?>