<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(@$title); ?></title>
    <style>
    .hid_spn {
        display: none !important;
    }
    </style>
</head>

<body>
    <table class="table table-striped table-responsive table-bordered table-hover table-checkable for_wdth">
        <thead>
            <?php if($type == 2 || $type == 3): ?>
            <tr>
                <?php if($type ==2): ?>
                <th colspan="9">
                    
                </th>
                <?php elseif($type ==3): ?>
                <th colspan="9">
                    Summary of job done (options for numbers or graph)
                </th>
                <?php endif; ?>
            </tr>
            
                
                
            
            <?php endif; ?>
            <?php if($type == 5): ?>
            <tr>
                <th colspan="6">Fitter : <?php echo e(@$name); ?> </th>
            </tr>
            <tr>
                <th><?php echo e(__('formname.report.no')); ?></th>
                <th><?php echo e(__('formname.report.date')); ?></th>
                <th><?php echo e(__('formname.job.machine')); ?></th>
                <th><?php echo e(__('formname.job.problem')); ?></th>
                <th><?php echo e(__('formname.job.job_status')); ?></th>
                <th><?php echo e(__('formname.job.job_hours')); ?></th>
                <th><?php echo e(__('formname.job.priority')); ?></th>
            </tr>
            <?php elseif($type == 6): ?>
            <tr>
                <th colspan="6"> <?php echo e(@$name); ?> </th>
            </tr>
            <tr>
                <th><?php echo e(__('formname.report.no')); ?></th>
                <th><?php echo e(__('formname.report.date')); ?></th>
                <th><?php echo e(__('formname.job.problem')); ?></th>
                <th><?php echo e(__('formname.job.assigned_to')); ?></th>
                <th><?php echo e(__('formname.job.job_hours')); ?></th>
                <th><?php echo e(__('formname.job.priority')); ?></th>
            </tr>
            <?php elseif($type == 7 || $type == 8 || $type == 9): ?>
            <tr>
                <th><?php echo e(__('formname.report.no')); ?></th>
                <th><?php echo e(__('formname.report.date')); ?></th>
                <th><?php echo e(__('formname.job.machine')); ?></th>
                <th><?php echo e(__('formname.job.assigned_to')); ?></th>
                <th><?php echo e(__('formname.job.job_hours')); ?></th>
                <th><?php echo e(__('formname.job.problem')); ?></th>
                <th><?php echo e(__('formname.job.comment')); ?></th>
                <th><?php echo e(__('formname.job.priority')); ?></th>
            </tr>
            <?php else: ?>
            <tr>
                <th><?php echo e(__('formname.report.no')); ?></th>
                <?php if($type == 4): ?>
                    <th><?php echo e(__('formname.report.engineer')); ?></th>
                <?php else: ?>
                    <th><?php echo e(@$title); ?> <?php echo e(isset($name)?'(In '.$name.')':''); ?></th>
                <?php endif; ?>
                <th><?php echo e(__('formname.report.total_job_request')); ?></th>
                <th><?php echo e(__('formname.report.job_request')); ?></th>
                <th><?php echo e(__('formname.report.assigned')); ?></th>
                <th><?php echo e(__('formname.report.work_order')); ?></th>
                <th><?php echo e(__('formname.report.complete')); ?></th>
                <th><?php echo e(__('formname.report.decline')); ?></th>
                <th><?php echo e(__('formname.report.kiv')); ?></th>
                <th><?php echo e(__('formname.report.unable_to_complete')); ?></th>
                <?php if($type == 4): ?>
                    
                <?php else: ?>
                    
                    
                <?php endif; ?>
                <th><?php echo e(__('formname.report.pending')); ?></th>
                <th><?php echo e(__('formname.report.preventive')); ?></th>
                <th><?php echo e(__('formname.report.normal')); ?></th>
                <th><?php echo e(__('formname.report.argent')); ?></th>
            </tr>
            <?php endif; ?>
        </thead>
        <tbody>
            <?php
                $i = 0;    
            ?>
            <?php if($type == 5): ?>
                <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $i++;
                ?>
                <tr>
                    <td><?php echo e(@$i); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($data->created_at))); ?></td>
                    <td><?php echo e(@$data->machine->title); ?></td>
                    <td><?php echo e(@$data->problem->title); ?></td>
                    <td><?php echo e(@config('constant.job_status_text')[$data->job_status_id]); ?></td>
                    <td><?php echo e(@$data->total_job_duration); ?></td>
                    <td><?php echo e(@config('constant.priorites_report_text')[$data->priority]); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" align="center">No records founds</td>
                    </tr>
                <?php endif; ?>
            <?php elseif($type == 6): ?>
                <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $i++;
                ?>
                <tr>
                    <td><?php echo e(@$i); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($data->created_at))); ?></td>
                    <td><?php echo e(@$data->problem->title); ?></td>
                    <td><?php echo e(@$data->assignedTo->full_name); ?></td>
                    <td><?php echo e(@$data->total_job_duration); ?></td>
                    <td><?php echo e(@config('constant.priorites_report_text')[$data->priority]); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" align="center">No records founds</td>
                    </tr>
                <?php endif; ?>
            <?php elseif($type == 7 || $type == 8 || $type == 9): ?>
                <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $i++;
                ?>
                <tr>
                    <td><?php echo e(@$i); ?></td>
                    <td><?php echo e(date('d-m-Y', strtotime($data->created_at))); ?></td>
                    <td><?php echo e(@$data->machine->title); ?></td>
                    <td><?php echo e(@$data->assignedTo->full_name); ?></td>
                    <td><?php echo e(@$data->total_job_duration); ?></td>
                    <td><?php echo e(@$data->problem->title); ?></td>
                    <td><?php echo e(@$data->comment); ?></td>
                    <td><?php echo e(@config('constant.priorites_report_text')[$data->priority]); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" align="center">No records founds</td>
                    </tr>
                <?php endif; ?>
            <?php else: ?>
                <?php $__empty_1 = true; $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <?php
                        $i++;
                    ?>
                    <td><?php echo e($i); ?></td>
                    <?php if($type ==4): ?>
                        <td><?php echo e(@$data->full_name); ?></td>
                    <?php else: ?>
                        <td><?php echo e(@$data->title); ?></td>
                    <?php endif; ?>
                        <td><?php echo e(@$data->total_job_request); ?></td>
                        <td><?php echo e(@$data->job_request); ?></td>
                        <td><?php echo e(@$data->assigned); ?></td>
                        <td><?php echo e(@$data->work_order); ?></td>
                        <td><?php echo e(@$data->complete); ?></td>
                        <td><?php echo e(@$data->declined); ?></td>
                        <td><?php echo e(@$data->kiv); ?></td>
                        <td><?php echo e(@$data->unable_to_complete); ?></td>
                    <?php if($type ==4): ?>
                        
                    <?php else: ?>
                        
                        
                    <?php endif; ?>
                    <td><?php echo e(@$data->pending); ?></td>
                    <td><?php echo e(@$data->low); ?></td>
                    <td><?php echo e(@$data->medium); ?></td>
                    <td><?php echo e(@$data->high); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" align="center">No records founds</td>
                </tr>
                <?php endif; ?>                
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php
// exit;    
?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/exports/jobReport.blade.php ENDPATH**/ ?>