<?php $__env->startSection('content'); ?>
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->startSection('title', __('formname.permission_master.list')); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <!-- END: Subheader -->
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-portlet m-portlet--mobile">
            <div class="m-portlet__body">
                <div class="m-form__content">
                    <h5><?php echo e(__('formname.permission_master.list')); ?></h5>
                </div>
                <hr>
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <select class="form-control" name="action" id='action' aria-invalid="false">
                                <option value=""><?php echo e(__('formname.action_option')); ?></option>
                                <option value="<?php echo e(config('constant.delete')); ?>"><?php echo e(__('formname.delete')); ?></option>
                                <option value="On">On</option>
                                <option value="Off">Off</option>
                            </select>
                            
                            <a href="javascript:;" class="btn btn-primary submit_btn" id='action_submit'
                                data-url="<?php echo e(route('permission.multi_delete')); ?>"
                                data-table_name="permission_table"><?php echo e(__('formname.submit')); ?></a>
                            <button class="btn btn-info" style='margin:0px 0px 0px 12px' id='clr_filter'
                                data-table_name="permission_table"><?php echo e(__('formname.clear_filter')); ?></button>
                        </div>
                    </div>
                    <div class="m-portlet__head-tools">
                        <ul class="m-portlet__nav">
                            <li class="m-portlet__nav-item">
                                <a href="<?php echo e(Route('permission.create')); ?>"
                                    class="btn btn-accent m-btn m-btn--pill m-btn--custom m-btn--icon m-btn--air">
                                    <span>
                                        <i class="la la-plus"></i>
                                        <span><?php echo e(__('formname.new_record')); ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--begin: Datatable -->
                <table class="table table-striped- table-bordered table-hover table-checkable for_wdth" id="permission_table"
                    data-type="" data-url="<?php echo e(route('permission.datatable')); ?>">
                    <thead>
                        <tr>
                            <th class="nosort">
                                <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
                                    <input type="checkbox" value="" id="trade_checkbox" class="m-checkable allCheckbox">
                                    <span></span>
                                </label>
                            </th>
                            <th><?php echo e(__('formname.permission_master.title')); ?></th>
                            <th><?php echo e(__('formname.permission_master.user_type')); ?></th>
                            <th><?php echo e(__('formname.created_at')); ?></th>
                            <th><?php echo e(__('formname.permission_master.permission_status')); ?></th>
                            
                            <th><?php echo e(__('formname.action')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <td></td>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.permission_master.title')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.permission_master.user_type')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.created_at')); ?>"></th>
                            <th class="slct-wdth">
                                <?php echo Form::select('permission_status', @$permissionStatusList, @$permission->permission_status,
                                    ['class' =>'permissionStatusFilter form-control form-control-sm tbl-filter-column' ]); ?>

                            </th>
                            
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
var url = "<?php echo e(route('permission.datatable')); ?>";
var jobCheckUrl ="<?php echo e(route('user.job')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/permission-master/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/permission-master/index.blade.php ENDPATH**/ ?>