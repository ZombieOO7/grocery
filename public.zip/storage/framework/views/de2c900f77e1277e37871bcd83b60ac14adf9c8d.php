<?php
$setting = getWebSetting();
?>
<!--begin::Base Scripts -->
<script src="<?php echo e(asset('backend/dist/default/assets/vendors/base/vendors.bundle.js')); ?>" type="text/javascript">
</script>
<script src="<?php echo e(asset('backend/dist/default/assets/demo/default/base/scripts.bundle.js')); ?>"
    type="text/javascript"></script>
<!--end::Base Scripts -->
<!--begin::Page Vendors -->
<!--end::Page Vendors -->
<!--begin::Page Snippets -->
<script src="<?php echo e(asset('backend/dist/default/assets/app/js/dashboard.js')); ?>" type="text/javascript"></script>
<!--end::Page Snippets -->

<script src="<?php echo e(asset('backend/dist/default/assets/vendors/custom/datatables/datatables.bundle.js')); ?>"
    type="text/javascript"></script>
<script src="<?php echo e(asset('js/jquery.raty.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/common.js')); ?>" type="text/javascript"></script>
<?php if(isset($setting) && $setting->notify == 1): ?>
<script src="<?php echo e(asset('js/pusher.min.js')); ?>"></script>
<?php endif; ?>

<?php
    // $updateNotification = route('notification.update');
    // $appKey = env('PUSHER_APP_KEY');
    // $cluster = env('PUSHER_APP_CLUSTER');
?>
<script>
//Ajax Loader
// var updateNotification = ;
// var appKey = ;
// var cluster = ;
$(document).ready(function() {
    $(document).ajaxStart(function() {
        $(document).find('.main_loader').show();
    }).ajaxStop(function() {
        $(document).find('.fixedStar').raty({
            readOnly: true,
            path: base_url + '/images',
            starOff: 'small-star-off.png',
            starOn: 'small-star-on.png',
            half: true,
            start: $(document).find(this).attr('data-score')
        });
        $(document).find('.main_loader').hide();
    });
});
/* notification bell */

/*  */

<?php if(isset($setting) && $setting->notify == 1): ?>
<?php endif; ?>
</script>
<script src="<?php echo e(asset('sweetalert/sweetalert.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(str_replace('public/', '', URL('resources/lang/js/en/message.js'))); ?>"></script>
<?php echo $__env->yieldContent('inc_script'); ?>
<?php $__env->startComponent('vendor.sweetalert.view'); ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/includes/footerInc.blade.php ENDPATH**/ ?>