<?php $__env->startSection('content'); ?>
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->startSection('title', __('formname.user_list')); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <!-- END: Subheader -->
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-portlet m-portlet--mobile">

            <div class="m-portlet__body">
                <div class="m-form__content">
                    <h5><?php echo e(__('formname.user_list')); ?></h5>
                </div>
                <hr>
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                         <div class="m-portlet__head-title">
                            <select class="form-control" name="action" id='action' aria-invalid="false">
                                <option value=""><?php echo e(__('formname.action_option')); ?></option>
                                <option value="<?php echo e(config('constant.delete')); ?>"><?php echo e(__('formname.delete')); ?></option>
                                <option value="<?php echo e(config('constant.active')); ?>"><?php echo e(__('formname.active')); ?></option>
                                <option value="<?php echo e(config('constant.inactive')); ?>"><?php echo e(__('formname.inactive')); ?></option>
                            </select>
                            <a href="javascript:;" class="btn btn-primary submit_btn"id='action_submit'  data-job_url="<?php echo e(route('user.job_multiple')); ?>" data-url="<?php echo e(route('user_multi_delete')); ?>" data-table_name="user_table"><?php echo e(__('formname.submit')); ?></a>
                                <button class="btn btn-info" style='margin:0px 0px 0px 12px' id='clr_filter'
                                data-table_name="user_table"><?php echo e(__('formname.clear_filter')); ?></button>
                        </div>
                    </div>
                    <div class="m-portlet__head-tools">
                        <ul class="m-portlet__nav">
                            <?php if((\Auth::guard('admin')->user()->can('page create'))): ?>
                            <li class="m-portlet__nav-item">
                                <a href="<?php echo e(Route('user_create')); ?>"
                                    class="btn btn-accent m-btn m-btn--pill m-btn--custom m-btn--icon m-btn--air">
                                    <span>
                                        <i class="la la-plus"></i>
                                        <span><?php echo e(__('formname.new_record')); ?></span>
                                    </span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <!--begin: Datatable -->
                <table class="table table-striped- table-bordered table-hover table-checkable table-responsive" id="user_table">
                    <thead>
                        <tr>
                            <th class="nosort">
                                <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
                                    <input type="checkbox" value="" id="user_checkbox" class="m-checkable allCheckbox">
                                    <span></span>
                                </label>
                            </th>
                            
                            <th><?php echo e(__('formname.first_name')); ?></th>
                            <th><?php echo e(__('formname.last_name')); ?></th>
                            <th><?php echo e(__('formname.email')); ?></th>
                            
                            <th><?php echo e(__('formname.company.title')); ?></th>
                            <th><?php echo e(__('formname.company_position')); ?></th>
                            <th><?php echo e(__('formname.created_at')); ?></th>
                            <th><?php echo e(__('formname.status')); ?></th>
                            <th><?php echo e(__('formname.action')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <td></td>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.first_name')); ?>"></th>
                                     <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.last_name')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(__('formname.email')); ?>"></th>
                            
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                placeholder="<?php echo e(__('formname.company.title')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                placeholder="<?php echo e(__('formname.company_position')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                placeholder="<?php echo e(__('formname.created_at')); ?>"></th>

                          <th>
                                <select class="statusFilter form-control form-control-sm tbl-filter-column">
                                    <?php $__empty_1 = true; $__currentLoopData = $statusList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                            </th>
                            <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>
<!-- Show Description Modal -->
<div class="modal fade def_mod dtails_mdl" id="DescModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content ">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"></button>
            <div class="modal-body">
                <h3 class="mdl_ttl"></h3>
                <p class="mrgn_tp_20 show_desc" style="word-wrap: break-word;">
                </p>
                <button type="button" class="btn btn-success pull-right" data-dismiss="modal"><?php echo e(__('formname.close')); ?></button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php /*Load script to footer section*/?>

<?php $__env->startSection('inc_script'); ?>
<script>
var user_list_url = "<?php echo e(route('user_datatable')); ?>";
/** Show description modal */
$(document).on('click','.shw-dsc',function(e) {
    $(document).find('.show_desc').html($(this).attr('data-description'));
    $(document).find('.mdl_ttl').html($(this).attr('data-title'));
});
</script>
<script src="<?php echo e(asset('backend/js/user/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/user/index.blade.php ENDPATH**/ ?>