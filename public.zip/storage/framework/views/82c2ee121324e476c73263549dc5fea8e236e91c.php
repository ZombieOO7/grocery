<?php $__env->startSection('content'); ?>
<style>
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->startSection('title', __('formname.emailTemplate.label')); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <!-- END: Subheader -->
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-portlet m-portlet--mobile">
            <div class="m-portlet__body">
                <div class="m-form__content">
                    <h5><?php echo e(__('formname.emailTemplate.list')); ?></h5>
                </div>
                <hr>
                <div class="m-portlet__head" style="padding: 0 !important;">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            
                            
                            <button class="btn btn-info" style='' id='clr_filter'
                                data-table_name="email_template_table"><?php echo e(__('formname.clear_filter')); ?></button>
                        </div>
                    </div>
                    
                </div>
                <!--begin: Datatable -->
                <table class="table table-striped- table-bordered table-hover table-checkable for_wdth" id="email_template_table"
                    data-type="" data-url="<?php echo e(route('emailTemplate.datatable')); ?>">
                    <thead>
                        <tr>
                            
                            <th><?php echo e(__('formname.emailTemplate.title')); ?></th>
                            <th><?php echo e(__('formname.emailTemplate.subject')); ?></th>
                            <th><?php echo e(__('formname.created_at')); ?></th>
                            
                            <th><?php echo e(__('formname.action')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column" placeholder="<?php echo e(__('formname.emailTemplate.title')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column" placeholder="<?php echo e(__('formname.emailTemplate.subject')); ?>"></th>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column" placeholder="<?php echo e(__('formname.created_at')); ?>"></th>                            
                            
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
var url = "<?php echo e(route('emailTemplate.datatable')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/email-template/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/email-template/index.blade.php ENDPATH**/ ?>