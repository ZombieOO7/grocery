<div class="form-group m-form__group row">
    <?php echo Form::label(($type == 5 || $type == 6 || $type == 1 || $type == 3 || $type == 2)?$title.'*':$title,
    null,array('class'=>'col-form-label
    col-lg-2 col-sm-12')); ?>

    <div class="col-lg-6 col-md-9 col-sm-12">
        <div class="input-group">
            <?php echo Form::select($name,@$list,[],['class'=>'form-control ','id'=>$name,'multiple'=>false 
            ,'data-none-selected-text' => __('formname.select_type',['type'=>$title]) ]); ?>

        </div>
        <span class="dynamicError">
            <?php if($errors->has($name)): ?>
            <p class="errors"><?php echo e($errors->first($name)); ?></p>
            <?php endif; ?>
        </span>
        <span class="m-form__help"></span>
    </div>
</div>
<?php if($type == 6): ?>
<div class="form-group m-form__group row">
    <?php echo Form::label('Machine',
    null,array('class'=>'col-form-label
    col-lg-2 col-sm-12')); ?>

    <div class="col-lg-6 col-md-9 col-sm-12">
        <div class="input-group">
            <?php echo Form::select('machine_id',[],[],['class'=>'form-control ','id'=>'machine_id','multiple'=>false 
            ,'data-none-selected-text' => __('formname.select_type',['type'=>'Machine']) ]); ?>

        </div>
        <span class="machineError">
            <?php if($errors->has('machine_id')): ?>
            <p class="errors"><?php echo e($errors->first('machine_id')); ?></p>
            <?php endif; ?>
        </span>
        <span class="m-form__help"></span>
    </div>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/reports/_add_filter.blade.php ENDPATH**/ ?>