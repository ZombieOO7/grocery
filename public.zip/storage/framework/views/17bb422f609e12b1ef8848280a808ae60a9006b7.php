<?php if(Session::has('sweetalert.json')): ?>
    <script>
        swal(<?php echo Session::pull('sweetalert.json'); ?>);
    </script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/vendor/sweetalert/view.blade.php ENDPATH**/ ?>