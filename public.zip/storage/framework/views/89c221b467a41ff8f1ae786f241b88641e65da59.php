<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', @$title); ?>
<style>
    .commonSelect {
        width: 100% !important;
        overflow: hidden !important;
        white-space: pre !important;
        text-overflow: ellipsis !important;
    }
</style>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e(@$title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <a href="<?php echo e(route('job.index')); ?>"
                                    class="btn btn-secondary m-btn m-btn--air m-btn--custom">
                                    <span>
                                        <i class="la la-arrow-left"></i>
                                        <span><?php echo e(__('formname.back')); ?></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <?php if(isset($job) || !empty($job)): ?>
                        <?php echo e(Form::model($job, ['route' => ['job.store', @$job->uuid], 'method' => 'PUT','id'=>'m_form_1','class'=>'m-form m-form--fit m-form--label-align-right','files' => true,'autocomplete' => "off", 'enctype'=>'multipart/form-data'])); ?>

                        <?php else: ?>
                        <?php echo e(Form::open(['route' => 'job.store','method'=>'post','class'=>'m-form m-form--fit m-form--label-align-right','id'=>'m_form_1','files' => true,'autocomplete' => "off", 'enctype'=>'multipart/form-data'])); ?>

                        <?php endif; ?>
                        
                        
                        
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.location').'*', null,['class'=>'col-form-label col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <?php echo Form::select('location_id', @$locationList, @$job->location_id,
                                ['class' => 'form-control commonSelect' ,'id'=>'location_id' ]); ?>

                                <?php if($errors->has('location_id')): ?>
                                <p style="color:red;"><?php echo e($errors->first('location_id')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.machine').'*', null,['class'=>'col-form-label col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <?php echo Form::select('machine_id', @$machineList, @$job->machine_id,
                                ['class' => 'form-control commonSelect' ,'id'=>'machine_id', 'placeholder' => 'Select Machine' ]); ?>

                                <?php if($errors->has('machine_id')): ?>
                                <p style="color:red;"><?php echo e($errors->first('machine_id')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.problem').'*', null,['class'=>'col-form-label col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <?php echo Form::select('problem_id', @$problemList, @$job->problem_id,
                                ['class' => 'form-control commonSelect', 'id'=>'problem_id' ]); ?>

                                <?php if($errors->has('problem_id')): ?>
                                <p style="color:red;"><?php echo e($errors->first('problem_id')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if(@$job->id != null): ?>
                        
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.assigned_to').'*', null,['class'=>'col-form-label col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                <?php echo e(@$job->assignedTo->full_name_text); ?>

                            </div>
                        </div>
                        <?php endif; ?>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.comment').'', null,['class'=>'col-form-label
                            col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <div class="input-group">
                                    <?php echo Form::textarea('comment',@$job->comment,['class'=>'form-control
                                    m-input','id'=>'editor2']); ?>

                                </div>
                                <span class="contentError">
                                    <?php if($errors->has('comment')): ?> <p style="color:red;">
                                        <?php echo e($errors->first('comment')); ?></p> <?php endif; ?>
                                </span>
                                <span class="m-form__help"></span>
                            </div>
                        </div>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.priority').'*', null,['class'=>'col-form-label col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <?php echo Form::select('priority', @$jobPriorityList, @$job->priority,
                                ['class' => 'form-control commonSelect']); ?>

                                <?php if($errors->has('priority')): ?>
                                <p style="color:red;"><?php echo e($errors->first('priority')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if(@$job->id): ?>
                        <b>
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.job_status').'', null,['class'=>'col-form-label col-lg-3 col-sm-12']); ?>

                            <div class="col-form-label col-lg-6 col-md-9 col-sm-12" style="color:<?php echo e(@config('constant.job_status_color')[$job->job_status_id]); ?>">
                                <?php echo e(@$job->jobStatus->title); ?>

                            </div>
                        </div>
                        </b>
                        <?php endif; ?>

                        
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.job.images'), null,['class'=>'col-form-label
                            col-lg-3 col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <?php echo Form::file('image[]',['id'=>'imgInput','class'=>'form-control m-input','accept' =>
                                'image/*','multiple'=>'true']); ?>

                                <?php if($errors->has('image')): ?> <p style="color:red;">
                                    <?php echo e($errors->first('image')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if($jobImages): ?>
                        <div class="form-group m-form__group row offset-md-3">
                            <?php $__empty_1 = true; $__currentLoopData = $jobImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                            <div style="margin-left:5px;" id="job-<?php echo e($key); ?>">
                                <a class="deleteImage" href="javascript:;" id="<?php echo e(@$image->uuid); ?>"
                                    data-url="<?php echo e(route('image.delete')); ?>" data-key="job-<?php echo e($key); ?>" title="Delete Image">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                                <img src="<?php echo e(@$image->job_image); ?>" alt="" height="100px;" width="100px;"
                                    style="display:block;" />
                            </div>
                            
                            
                                
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <img id="blah" src="" data-count='<?php echo e(isset($jobImages)?count($jobImages):0); ?>' alt="" height="100px;" width="100px;" style="display:none;" />
                        <div class="form-group m-form__group row">
                            <?php echo Form::label(__('formname.status').'*', null,['class'=>'col-form-label col-lg-3
                            col-sm-12']); ?>

                            <div class="col-lg-6 col-md-9 col-sm-12">
                                <?php echo Form::select('status', @$statusList, @$job->status,
                                ['class' => 'form-control' ]); ?>

                                 <?php if($errors->has('status')): ?> <p style="color:red;">
                                    <?php echo e($errors->first('status')); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php echo Form::hidden('id',@$job->id ,['id'=>'id']); ?>

                        <div class="m-portlet__foot m-portlet__foot--fit">
                            <div class="m-form__actions m-form__actions">
                                <br>
                                <div class="row">
                                    <div class="col-lg-9 ml-lg-auto">
                                        <?php echo Form::submit(__('formname.submit'), ['class' => 'btn btn-success'] ); ?>

                                        <a href="<?php echo e(Route('job.index')); ?>"
                                            class="btn btn-secondary"><?php echo e(__('formname.cancel')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script src="https://cdn.ckeditor.com/4.10.1/standard/ckeditor.js"></script>
<script>
    var rule = $.extend({}, <?php echo json_encode(config('constant'), JSON_FORCE_OBJECT); ?>);
    var formname = $.extend({}, <?php echo json_encode(__('formname'), JSON_FORCE_OBJECT); ?>);
    var id = '<?php echo e(@$job->id); ?>';
    var getMachineList = "<?php echo e(route('getmachine')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/job/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/job/create.blade.php ENDPATH**/ ?>