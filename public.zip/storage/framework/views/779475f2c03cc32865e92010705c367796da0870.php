    <a class=" view" href="<?php echo e(URL::signedRoute('category.edit',['uuid'=>@$category->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" href="javascript:;" id="<?php echo e(@$category->uuid); ?>" data-table_name="category_table" data-url="<?php echo e(route('category.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$category->status=='1'): ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$category->uuid); ?>" data-url="<?php echo e(route('category.active_inactive', [@$category->id])); ?>" data-table_name="category_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$category->uuid); ?>" data-url="<?php echo e(route('category.active_inactive', [@$category->id])); ?>" data-table_name="category_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/admin/category/_add_action.blade.php ENDPATH**/ ?>