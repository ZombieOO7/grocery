<a class=" view" href="<?php echo e(URL::signedRoute('machine.print',['uuid'=>@$machine->uuid])); ?>" title="Print Qr Code">
    <i class="fas fa-print"></i>
</a>
<?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/machine/_add_print.blade.php ENDPATH**/ ?>