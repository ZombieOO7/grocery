<?php $__env->startSection('inc_css'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-colorpicker/2.5.3/css/bootstrap-colorpicker.min.css"
    rel="stylesheet">
<style>
    label {
        font-weight: 600;
    }
    .hid_spn{
        display: none !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
if(isset($user)){
$title=__('formname.user_detail');
}
else{
$title=__('formname.user_detail');
}
if(URL::previous() == Request::fullUrl()){
    $backurl = route('user_index');
}else{
    $backurl = URL::previous();
}
?>

<?php $__env->startSection('title', $title); ?>

<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-lg-12">
                <!--begin::Portlet-->
                <div class="m-portlet m-portlet--last m-portlet--head-lg m-portlet--responsive-mobile"
                    id="main_portlet">
                    <div class="m-portlet__head">
                        <div class="m-portlet__head-wrapper">
                            <div class="m-portlet__head-caption">
                                <div class="m-portlet__head-title">
                                    <h3 class="m-portlet__head-text">
                                        <?php echo e($title); ?>

                                    </h3>
                                </div>
                            </div>
                            <div class="m-portlet__head-tools">
                                <a href="<?php echo e($backurl); ?>"
                                    class="btn btn-secondary m-btn m-btn--air m-btn--custom">
                                    <span>
                                        <i class="la la-arrow-left"></i>
                                        <span>Back</span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="m-portlet__body">
                        <div class="m-wizard__form-step m-wizard__form-step--current" id="web_setting_form_step">
                            <div class="row">
                                <div class="col-xl-12">
                                    <ul class="nav nav-tabs m-tabs-line--2x m-tabs-line m-tabs-line--danger"
                                        role="tablist">
                                        <li class="nav-item m-tabs__item">
                                            <a class="nav-link m-tabs__link active" data-toggle="tab" href="#profile"
                                                role="tab">Profile Info</a>
                                        </li>
                                        <li class="nav-item m-tabs__item">
                                            <a class="nav-link m-tabs__link" data-toggle="tab" href="#job"
                                                role="tab">Job Detail</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content m--margin-top-40">
                                        <div class="tab-pane active" id="profile" role="tabpanel">
                                            <div class="m-form__section m-form__section--first">
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.first_name').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@$user->first_name); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.last_name').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3 col-sm-12']); ?>

                                                    <div class="col-lg-2 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@$user->last_name); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.email').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@$user->email); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.phone').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3 col-sm-12']); ?>

                                                    <div class="col-lg-2 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@$user->phone); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.company.title').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@$user->company->title); ?>

                                                    </div>
                                                </div>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.company_position').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@config('constant.user_types')[$user->user_type]); ?>

                                                    </div>
                                                </div>
                                                
                                                
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.profile_picture') .' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3 col-sm-12']); ?>

                                                    <div class="col-lg-6 col-md-9 col-sm-12">
                                                        
                                                        <img id="blah" src="<?php echo e(@$user->profile_image); ?>" alt=""
                                                            height="100px;" width="100px;" style="display:block;" />
                                                        
                                                    </div>
                                                </div>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.register_as_user').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-6 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(@$user->register_as_user_text); ?>

                                                    </div>
                                                </div>
                                                <?php if((\Auth::guard('admin')->user()->can('user active inactive'))): ?>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label('Active/Inactive : ', null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-3 col-md-9 col-sm-12">
                                                        <?php if(@$user->status=='1'): ?>
                                                        <a class="cd-stts active_inactive_user userStatus"
                                                            href="javascript:;" id="<?php echo e(@$user->id); ?>"
                                                            data-url="<?php echo e(route('user_active_inactive', [@$user->id])); ?>"
                                                            data-status=<?php echo e(@$user->status); ?> data-table_name="user_table"
                                                            title="Active User">
                                                            <i class="fas fa-toggle-on" id="tggl-clss"
                                                                style="font-size: 25px;"></i>
                                                        </a>
                                                        <?php else: ?>
                                                        <a class="cd-stts active_inactive_user userStatus"
                                                            href="javascript:;" id="<?php echo e(@$user->id); ?>"
                                                            data-url="<?php echo e(route('user_active_inactive', [@$user->id])); ?>"
                                                            data-status=<?php echo e(@$user->status); ?> data-table_name="user_table"
                                                            title="Inactive User">
                                                            <i class="fas fa-toggle-off" id="tggl-clss"
                                                                style="font-size: 25px;"></i>
                                                        </a>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if((\Auth::guard('admin')->user()->can('user delete'))): ?>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label('Delete User : ', null,['class'=>'col-form-label
                                                    col-lg-3
                                                    col-sm-12']); ?>

                                                    <div class="col-lg-3 col-md-9 col-sm-12">
                                                        <a class="deleteUser" href="javascript:;" id="<?php echo e(@$user->id); ?>"
                                                            data-table_name="user_table"
                                                            data-url="<?php echo e(route('user_delete')); ?>" title="Delete User">
                                                            <i class="fas fa-trash-alt" id="tggl-clss"
                                                                style="font-size: 25px;"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if($user->is_verify == 0): ?>
                                                <div class="form-group m-form__group row">
                                                    <?php echo Form::label(__('formname.verify_user').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3 col-sm-12']); ?>

                                                    <div class="col-lg-3 col-md-9 col-sm-12 col-form-label">
                                                        <a href="<?php echo e(Route('user_verify',[@$user->id,1])); ?>"
                                                            class="btn btn-success"><?php echo e(__('formname.verify')); ?></a>
                                                        <a href="<?php echo e(Route('user_verify',[@$user->id,2])); ?>"
                                                            class="btn btn-danger"><?php echo e(__('formname.decline')); ?></a>
                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                                <?php if($user->is_verify != 0): ?>
                                                <div class="form-group m-form__group row">
                                                <?php echo Form::label(__('formname.verified_label').' : ',
                                                    null,['class'=>'col-form-label
                                                    col-lg-3 col-sm-12']); ?>

                                                    <div class="col-lg-3 col-md-9 col-sm-12 col-form-label">
                                                        <?php echo e(__('formname.verified_status',['status'=>(@$user->is_verify==1)?'verified':'declined'])); ?>

                                                    </div>
                                                </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="job" role="tabpanel">
                                            <div class="m-form__section m-form__section--first">
                                                
                                                <table
                                                    class="table table-striped- table-bordered table-hover table-checkable for_wdth"
                                                    id="job_table" data-type="" data-url="<?php echo e(route('job.datatable')); ?>">
                                                    <thead>
                                                        <tr>
                                                            
                                                            <th><?php echo e(__('formname.job.machine')); ?></th>
                                                            <th><?php echo e(__('formname.job.problem')); ?></th>
                                                            <th><?php echo e(__('formname.job.location')); ?></th>
                                                            <th><?php echo e(__('formname.job.requested_by')); ?></th>
                                                            <th><?php echo e(__('formname.job.priority')); ?></th>
                                                            <th><?php echo e(__('formname.job.job_status')); ?></th>
                                                            <th><?php echo e(__('formname.created_at')); ?></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr>
                                                                
                                                                <td><?php echo e(@$job->machine->title); ?></td>
                                                                <td><?php echo e(@$job->problem->title); ?></td>
                                                                <td><?php echo e(@$job->location->title); ?></td>
                                                                <td><?php echo e(@$job->created_by_text); ?></td>
                                                                <td><?php echo e(@config('constant.priorites')[$job->priority]); ?></td>
                                                                <td><?php echo e(@config('constant.job_status_text')[$job->job_status_id]); ?></td>
                                                                <td><?php echo @$job->proper_created_at; ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr>
                                                                <td colspan="7" class="text-center">No jobs found</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('inc_script'); ?>
<script>
    var returnUrl="<?php echo e(Route('user_index')); ?>";
    var jobCheckUrl = "<?php echo e(route('user.job')); ?>";
    var getRoleUrl = "<?php echo e(route('get-user-role')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/user/create.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>