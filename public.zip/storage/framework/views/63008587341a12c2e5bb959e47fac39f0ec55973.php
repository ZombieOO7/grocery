<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', trans('formname.admin_list')); ?>
<div class="m-grid__item m-grid__item--fluid m-wrapper">
    <!-- END: Subheader -->
    <div class="m-content">
        <?php echo $__env->make('admin.includes.flashMessages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="m-portlet m-portlet--mobile">
            <div class="m-portlet__body">
                <div class="m-form__content">
                    <h5><?php echo e(trans('formname.admin_list')); ?></h5>
                </div>
                <hr>
                <div class="m-portlet__head">
                    <div class="m-portlet__head-caption">
                        <div class="m-portlet__head-title">
                            <select class="form-control" name="action" id='action' aria-invalid="false">
                                <option value=""><?php echo e(trans('formname.action')); ?></option>
                                <?php if((\Auth::guard('admin')->user()->can('admin multiple delete'))): ?>
                                <option value="delete"><?php echo e(trans('formname.delete')); ?></option>
                                <?php endif; ?>
                                <?php if((\Auth::guard('admin')->user()->can('admin multiple active'))): ?>
                                <option value="active"><?php echo e(trans('formname.active')); ?></option>
                                <?php endif; ?>
                                <?php if((\Auth::guard('admin')->user()->can('admin multiple inactive'))): ?>
                                <option value="inactive"><?php echo e(trans('formname.inactive')); ?></option>
                                <?php endif; ?>
                            </select>
                            <a href="javascript:;" class="btn btn-primary submit_btn"id='action_submit' data-url="<?php echo e(route('admin_multi_delete')); ?>" data-table_name="admin_table"><?php echo e(trans('formname.submit')); ?></a>
                                 <button class="btn btn-info" style='margin:0px 0px 0px 12px' id='clr_filter'
                                data-table_name="admin_table"><?php echo e(trans('formname.clear_filter')); ?></button>
                        </div>
                    </div>
                    <div class="m-portlet__head-tools">
                        <ul class="m-portlet__nav">
                            <?php if((\Auth::guard('admin')->user()->can('admin create'))): ?>
                            <li class="m-portlet__nav-item">
                                <a href="<?php echo e(Route('admin_create')); ?>"
                                    class="btn btn-accent m-btn m-btn--pill m-btn--custom m-btn--icon m-btn--air">
                                    <span>
                                        <i class="la la-plus"></i>
                                        <span><?php echo e(trans('formname.new_record')); ?></span>
                                    </span>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <!--begin: Datatable -->
        <table class="table table-striped- table-bordered table-hover table-checkable" id="admin_table">
                    <thead>
                        <tr>
                            <th class="nosort">
                                <label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
                                    <input type="checkbox" value="" id="admin_checkbox" class="m-checkable allCheckbox">
                                    <span></span>
                                </label>
                            </th>
                            <th><?php echo e(trans('formname.id')); ?></th>
                            <th><?php echo e(trans('formname.first_name')); ?></th>
                            <th><?php echo e(trans('formname.last_name')); ?></th>
                            <th><?php echo e(trans('formname.email')); ?></th>
                            <th><?php echo e(trans('formname.status')); ?></th>
                            <th><?php echo e(trans('formname.action')); ?></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <td></td>
                            <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.id')); ?>"></th>
                          <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.first_name')); ?>"></th>
                           <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.last_name')); ?>"></th>
                          <th><input type="text" class="form-control form-control-sm tbl-filter-column"
                                    placeholder="<?php echo e(trans('formname.email')); ?>"></th>
                           <th>
                                <select class="statusFilter form-control form-control-sm tbl-filter-column">
                                    <?php $__empty_1 = true; $__currentLoopData = $statusList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </select>
                            </th>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>
        <!-- END EXAMPLE TABLE PORTLET-->
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php /*Load script to footer section*/?>

<?php $__env->startSection('inc_script'); ?>
<script>
var admin_list_url = "<?php echo e(route('admin_datatable')); ?>";
</script>
<script src="<?php echo e(asset('backend/js/admin/index.js')); ?>" type="text/javascript"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/admin/index.blade.php ENDPATH**/ ?>