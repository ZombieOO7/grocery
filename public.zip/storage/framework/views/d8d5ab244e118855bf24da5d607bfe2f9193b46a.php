Error on : <?php echo e(url()->full()); ?>

</br>
<?php echo $content; ?><?php /**PATH C:\xampp\htdocs\grocery\resources\views/email/exception.blade.php ENDPATH**/ ?>