    <a class=" view" href="<?php echo e(URL::signedRoute('user-role.edit',['uuid'=>@$userRole->uuid])); ?>" title="Edit">
        <i class="fas fa-pencil-alt"></i>
    </a>
    <a class="delete" href="javascript:;" id="<?php echo e(@$userRole->id); ?>" data-table_name="user_role_table" data-url="<?php echo e(route('user-role.delete')); ?>" title="Delete">
        <i class="fas fa-trash-alt"></i>
    </a>
    <?php if(@$userRole->status=='1'): ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$userRole->id); ?>" data-url="<?php echo e(route('user-role.active_inactive', [@$userRole->id])); ?>" data-table_name="user_role_table" title="Active">
            <i class="fas fa-toggle-on"></i>
        </a>
    <?php else: ?>
        <a class=" active_inactive" href="javascript:;" id="<?php echo e(@$userRole->id); ?>" data-url="<?php echo e(route('user-role.active_inactive', [@$userRole->id])); ?>" data-table_name="user_role_table" title="Inactive">
            <i class="fas fa-toggle-off"></i>
        </a>
    <?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/user-role/_add_action.blade.php ENDPATH**/ ?>