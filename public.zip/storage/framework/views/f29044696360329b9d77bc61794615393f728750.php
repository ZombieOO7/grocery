<?php echo e(Str::limit(@$contact->subject, 30)); ?>

<?php if(strlen(@$contact->subject) >= 30): ?>
    <a href="javascript:void(0);" class="shw-dsc" data-subject="<?php echo e(@$contact->subject); ?>" data-description="<?php echo e(@$contact->subject); ?>" data-toggle="modal" data-target="#SubjModal"><?php echo e(__('formname.read_more')); ?></a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\open_ipps\resources\views/admin/contact-us/_add_subject.blade.php ENDPATH**/ ?>