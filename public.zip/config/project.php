<?php

return [
    'dev_email' => 'bhumika@webcluesinfotech.com',
    'APP_NAME'  => env('APP_NAME'),
    'MAIL_FROM'  => ['address' => env('MAIL_FROM_ADDRESS'), 'name' => env('APP_NAME')],
];