<?php

return [
    '1' => 'superadmin',
    '2' => 'frontend',
    '3' => 'other',
    // ['name' => 'superadmin', 'guard_name' => 'admin'],
    // ['name' => 'frontend', 'guard_name' => 'web'],
    // ['name' => 'other', 'guard_name' => 'web'],
];