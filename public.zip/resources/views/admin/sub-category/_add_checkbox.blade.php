<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="trade_checkbox[]" value="{{@$subCategory->id}}" class="m-checkable trade_checkbox checkbox">
    <span></span>
</label>