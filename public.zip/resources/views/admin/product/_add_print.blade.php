<a class=" view" href="{{ URL::signedRoute('product.print',['uuid'=>@$product->uuid]) }}" title="Print Qr Code">
    <i class="fas fa-print"></i>
</a>
