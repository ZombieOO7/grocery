<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="cms_checkbox[]" value="{{@$cms->id}}" class="m-checkable cms_checkbox checkbox">
    <span></span>
</label>
