<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="user_checkbox[]" value="{{$user->id}}" class="m-checkable user_checkbox checkbox">
    <span></span>
</label>