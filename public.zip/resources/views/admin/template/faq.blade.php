<tr>
    <td>
        <table width="100%" cellpadding="0" cellspacing="0"
            style="width: 100%;font-family: 'Poppins', sans-serif !important;">
            <tbody>
                <tr>
                    <td
                        style="font-family: 'Poppins', sans-serif !important;font-weight: 500;font-size: 12px;color: #616161;text-align: center;border-top: 1px solid #e6e6e6;padding: 15px;">
                        Kindly read our 
                        {{-- <a href="{{ route('faq',['slug' =>  @$faqs[0]->frontendFaqs ? @$faqs[0]->frontendFaqs[0]->slug : 'not-found' ]) }}"
                            style="text-decoration: none;color: #2196f3;">FAQ’s</a> --}}
                        for any issues. </td>
                </tr>
                {{-- <tr>
                    <td style="text-align: center;">
                        <a href="#" style="text-decoration: none;"><img
                                src={{ asset("frontend/images/templates/facebook.png") }}
                                style="max-width: 30px;margin-right: 5px;"></a>
                        <a href="#" style="text-decoration: none;"><img
                                src={{ asset("frontend/images/templates/twitter.png") }}
                                style="max-width: 30px;"></a>
                    </td>
                </tr> --}}
                <tr>
                    <td height="5px"></td>
                </tr>
            </tbody>
        </table>
    </td>
</tr>