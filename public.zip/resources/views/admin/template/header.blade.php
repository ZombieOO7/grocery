<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title></title>
    <link
        href="https://fonts.googleapis.com/css?family=Poppins:400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap"
        rel="stylesheet">
</head>
<style type="text/css">

</style>

<body>
<table width="800px" cellpadding="0" cellspacing="0"
    style="font-family: 'Poppins', sans-serif !important;box-sizing:border-box;margin:0 auto;padding:0;width:800px;max-width: 800px;">
    <tbody>
        <tr>
            <td>
                <table width="100%" cellpadding="0" cellspacing="0"
                    style="background-color:#1a237e;width: 100%;text-align: center;">
                    <tbody>
                        <tr>
                            <td height="15px"></td>
                        </tr>
                        <tr>
                            <td><a href="{{url('/')}}"><img src="{{ asset('images/favicon@64x64.png') }}"
                                        style="max-width: 150px;"></a></td>
                        </tr>
                        <tr>
                            <td height="15px"></td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
