<a class=" view" href="{{ URL::signedRoute('machine.print',['uuid'=>@$machine->uuid]) }}" title="Print Qr Code">
    <i class="fas fa-print"></i>
</a>
