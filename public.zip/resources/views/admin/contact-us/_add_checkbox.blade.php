<label class="m-checkbox m-checkbox--single m-checkbox--solid m-checkbox--brand">
    <input type="checkbox" name="contact_us_checkbox[]" value="{{@$contact->id}}" class="m-checkable contact_us_checkbox checkbox checkAll" data-email="{{ @$contact->email }}">
    <span></span>
</label>
