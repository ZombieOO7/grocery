Error on : {{ url()->full() }}
</br>
{!! $content !!}