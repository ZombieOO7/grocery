var message = [];
/**Common messages */
message['sure'] = 'Are you sure?';
message['once'] = 'Once updated, you will not be able to recover this data!';
message['once_deleted'] = "Once deleted, you will not be able to recover this data!";
message['once_updated_status'] = 'Once changed, you can update status anytime!';
message['change_status']='you want to change status!';
message['select_checkbox'] = 'Please select at least one checkbox';
message['select_action']="Please select action";
