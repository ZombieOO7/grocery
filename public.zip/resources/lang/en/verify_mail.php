<?php

return [
    // From Name
    'mail_txt_1' => 'Please click the link below to verify your email address.',
    'mail_txt_2' => 'Verify Email Address',
    'mail_txt_3' => 'If you did not create an account, no further action is required.',
    'mail_txt_4' => 'Regards,',
    'mail_txt_5' => 'If you’re having trouble clicking the "Verify Email Address" button, copy and paste the URL below
    into your web browser',
];
